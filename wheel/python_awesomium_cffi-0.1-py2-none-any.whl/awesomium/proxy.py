from __future__ import (print_function, division, absolute_import)

################################################################################

import weakref
import logging
from ._awesomium import *
from .internal import LIBDIR, _ffi

################################################################################

log = logging.getLogger('awesomium')

################################################################################

class String:
    @staticmethod
    def wrap(s):
        if not s:
            return awe_string_empty()
        else:
            p = awe_string_create_from_utf8(s, len(s))
            return _ffi.gc(p, awe_string_destroy) #@UndefinedVariable
    
    @staticmethod
    def unwrap(s):
        size = awe_string_to_utf8(s, _ffi.NULL, 0) #@UndefinedVariable
        p = _ffi.new('char[]', size) #@UndefinedVariable
        awe_string_to_utf8(s, p, size)
        return _ffi.string(p) #@UndefinedVariable

################################################################################

class WebCore(object):
    @classmethod
    def initialize(cls, enable_plugins = False, enable_javascript = True, 
            enable_databases = False, package_path = LIBDIR, locale_path = None, 
            user_data_path = None, plugin_path = None, log_path = None, 
            log_level = AWE_LL_NONE, force_single_process = False, 
            child_process_path = None, enable_auto_detect_encoding = True, 
            accept_language_override = None, default_charset_override = None,
            user_agent_override = None, proxy_server = None,
            proxy_config_script = None, auth_server_whitelist = None, 
            save_cache_and_cookies = True, max_cache_size = 0, 
            disable_same_origin_policy = False, 
            disable_win_message_pump = False, custom_css = None):
        awe_webcore_initialize(enable_plugins, enable_javascript, 
            enable_databases, String.wrap(package_path), 
            String.wrap(locale_path), String.wrap(user_data_path), 
            String.wrap(plugin_path), String.wrap(log_path), log_level, 
            force_single_process, String.wrap(child_process_path), 
            enable_auto_detect_encoding, String.wrap(accept_language_override),
            String.wrap(default_charset_override), 
            String.wrap(user_agent_override), String.wrap(proxy_server), 
            String.wrap(proxy_config_script), 
            String.wrap(auth_server_whitelist), save_cache_and_cookies,
            max_cache_size, disable_same_origin_policy,
            disable_win_message_pump, String.wrap(custom_css))
    
    @classmethod
    def initialize_default(cls):
        awe_webcore_initialize_default()

    @classmethod
    def shutdown(cls):
        awe_webcore_shutdown()
        
    @classmethod
    def set_base_directory(cls, base_dir_path):
        awe_webcore_set_base_directory (String.wrap(base_dir_path))

    @classmethod
    def set_custom_response_page(cls, status_code, file_path):
        awe_webcore_set_custom_response_page(status_code, String.wrap(file_path))
        
    @classmethod
    def update(cls):
        awe_webcore_update()
        
    @classmethod
    def get_base_directory(cls):
        return String.unwrap(awe_webcore_get_base_directory())
    
    @classmethod
    def are_plugins_enabled(cls):
        awe_webcore_are_plugins_enabled ()
    
    @classmethod
    def clear_cache(cls):
        awe_webcore_clear_cache ()
        
    @classmethod
    def clear_cookies(cls):
        awe_webcore_clear_cookies ()
    
    @classmethod
    def set_cookie(cls, url, cookie_string, is_http_only, force_session_cookie): 
        awe_webcore_set_cookie (String.wrap(url), String.wrap(cookie_string), 
            is_http_only, force_session_cookie)
    
    @classmethod
    def get_cookies(cls, url, exclude_http_only):
        return String.unwrap(awe_webcore_get_cookies (
            String.wrap(url), exclude_http_only))
    
    @classmethod
    def delete_cookie(cls, url, cookie_name):
        awe_webcore_delete_cookie (String.wrap(url), String.wrap(cookie_name))
    
    @classmethod
    def set_suppress_printer_dialog(cls, suppress):
        awe_webcore_set_suppress_printer_dialog (suppress)
        
    @classmethod
    def query_history(cls, full_text_query, num_days_ago, max_count):
        return awe_webcore_query_history (String.wrap(full_text_query), 
            num_days_ago, max_count)
        
    @classmethod
    def create_webview(cls, width, height, view_source = False):
        return WebView(awe_webcore_create_webview(width, height, view_source), managed = True)

################################################################################

class WebView(object):
    def __init__(self, ptr, managed = False):
        if managed:
            ptr = _ffi.gc(ptr, awe_webview_destroy) #@UndefinedVariable
        self._ptr = ptr
    
    def destroy(self):
        self._ptr = None
    
    def load_url(self, url, frame_name = None, username = None, password = None):
        awe_webview_load_url (self._ptr, String.wrap(url), 
            String.wrap(frame_name), String.wrap(username), 
            String.wrap(password))
    
    def load_html(self, html, frame_name = None):
        awe_webview_load_html (self._ptr, String.wrap(html), 
            String.wrap(frame_name))
    
    def load_file(self, filepath, frame_name = None):
        awe_webview_load_file (self._ptr, String.wrap(filepath), 
            String.wrap(frame_name))
        
    def get_url(self):
        return String.unwrap(awe_webview_get_url (self._ptr))

    def is_dirty(self):
        return awe_webview_is_dirty(self._ptr)
    
    def render(self):
        return RenderBuffer(self) 

    def inject_mouse_move(self, x, y):
        awe_webview_inject_mouse_move(self._ptr, x, y)
        
    def inject_mouse_down(self, button):
        awe_webview_inject_mouse_down(self._ptr, button)
        
    def inject_mouse_up(self, button):
        awe_webview_inject_mouse_up(self._ptr, button)
        
    def inject_mouse_wheel(self, scroll_amount_vert, scroll_amount_horz):
        awe_webview_inject_mouse_wheel (
            self._ptr, scroll_amount_vert, scroll_amount_horz)
    
    def inject_keyboard_event(self, key_event):
        awe_webview_inject_keyboard_event (self._ptr, key_event[0])
        
    def cut(self):
        awe_webview_cut(self._ptr)
        
    def copy(self):
        awe_webview_copy(self._ptr)
        
    def paste(self):
        awe_webview_paste(self._ptr)
        
    def select_all(self):
        awe_webview_select_all(self._ptr)

    def set_transparent(self, is_transparent):
        awe_webview_set_transparent (self._ptr, is_transparent)
        
    def is_transparent(self):
        return awe_webview_is_transparent(self._ptr)

    def go_to_history_offset(self, offset):
        awe_webview_go_to_history_offset(self._ptr, offset)

    def get_history_back_count(self):
        return awe_webview_get_history_back_count(self._ptr)

    def get_history_forward_count(self):
        return awe_webview_get_history_forward_count(self._ptr)

    def stop(self):
        awe_webview_stop(self._ptr)

    def reload(self):
        awe_webview_reload(self._ptr)

    def execute_javascript(self, javascript, frame_name):
        awe_webview_execute_javascript(self._ptr, String.wrap(javascript), String.wrap(frame_name))

    def execute_javascript_with_result(self, javascript, frame_name, timeout_ms):
        return awe_webview_execute_javascript_with_result(self._ptr, String.wrap(javascript), String.wrap(frame_name), timeout_ms)

    def call_javascript_function(self, obj, function, arguments, frame_name):
        awe_webview_call_javascript_function(self._ptr, String.wrap(obj), String.wrap(function), arguments, String.wrap(frame_name))

    def create_object(self, object_name):
        awe_webview_create_object(self._ptr, String.wrap(object_name))

    def destroy_object(self, object_name):
        awe_webview_destroy_object(self._ptr, String.wrap(object_name))

    def set_object_property(self, object_name, property_name, value):
        awe_webview_set_object_property(self._ptr, String.wrap(object_name), String.wrap(property_name), JSValue.create(value)._ptr)

    def set_object_callback(self, object_name, callback_name):
        awe_webview_set_object_callback(self._ptr, String.wrap(object_name), String.wrap(callback_name))

    def is_loading_page(self):
        return awe_webview_is_loading_page(self._ptr)

    def get_dirty_bounds(self):
        return awe_webview_get_dirty_bounds(self._ptr)

    def pause_rendering(self):
        awe_webview_pause_rendering(self._ptr)

    def resume_rendering(self):
        awe_webview_resume_rendering(self._ptr)

    def copy_image_at(self, x, y):
        awe_webview_copy_image_at(self._ptr, x, y)

    def set_zoom(self, zoom_percent):
        awe_webview_set_zoom(self._ptr, zoom_percent)

    def reset_zoom(self):
        awe_webview_reset_zoom(self._ptr)

    def get_zoom(self):
        return awe_webview_get_zoom(self._ptr)

    def get_zoom_for_host(self, host):
        return awe_webview_get_zoom_for_host(self._ptr, String.wrap(host))

    def resize(self, width, height, wait_for_repaint, repaint_timeout_ms):
        return awe_webview_resize(self._ptr, width, height, wait_for_repaint, repaint_timeout_ms)

    def is_resizing(self):
        return awe_webview_is_resizing(self._ptr)

    def unfocus(self):
        awe_webview_unfocus(self._ptr)

    def focus(self):
        awe_webview_focus(self._ptr)

    def set_url_filtering_mode(self, mode):
        awe_webview_set_url_filtering_mode(self._ptr, mode)

    def add_url_filter(self, filt):
        awe_webview_add_url_filter(self._ptr, String.wrap(filt))

    def clear_all_url_filters(self):
        awe_webview_clear_all_url_filters(self._ptr)

    def set_header_definition(self, name, num_fields, field_names, field_values):
        awe_webview_set_header_definition(self._ptr, String.wrap(name), num_fields, String.wrap(field_names), String.wrap(field_values))

    def add_header_rewrite_rule(self, rule, name):
        awe_webview_add_header_rewrite_rule(self._ptr, String.wrap(rule), String.wrap(name))

    def remove_header_rewrite_rule(self, rule):
        awe_webview_remove_header_rewrite_rule(self._ptr, String.wrap(rule))

    def remove_header_rewrite_rules_by_definition_name(self, name):
        awe_webview_remove_header_rewrite_rules_by_definition_name(self._ptr, String.wrap(name))

    def choose_file(self, file_path):
        awe_webview_choose_file(self._ptr, String.wrap(file_path))

    def print_(self):
        awe_webview_print(self._ptr)

    def request_scroll_data(self, frame_name):
        awe_webview_request_scroll_data(self._ptr, String.wrap(frame_name))

    def find(self, request_id, search_string, forward, case_sensitive, find_next):
        awe_webview_find(self._ptr, request_id, String.wrap(search_string), forward, case_sensitive, find_next)

    def stop_find(self, clear_selection):
        awe_webview_stop_find(self._ptr, clear_selection)

    def translate_page(self, source_language, target_language):
        awe_webview_translate_page(self._ptr, String.wrap(source_language), String.wrap(target_language))

    def activate_ime(self, activate):
        awe_webview_activate_ime(self._ptr, activate)

    def set_ime_composition(self, input_string, cursor_pos, target_start, target_end):
        awe_webview_set_ime_composition(self._ptr, String.wrap(input_string), cursor_pos, target_start, target_end)

    def confirm_ime_composition(self, input_string):
        awe_webview_confirm_ime_composition(self._ptr, String.wrap(input_string))

    def cancel_ime_composition(self):
        awe_webview_cancel_ime_composition(self._ptr)

    def login(self, request_id, username, password):
        awe_webview_login(self._ptr, request_id, String.wrap(username), String.wrap(password))

    def cancel_login(self, request_id):
        awe_webview_cancel_login(self._ptr, request_id)

    def close_javascript_dialog(self, request_id, was_cancelled, prompt_text):
        awe_webview_close_javascript_dialog(self._ptr, request_id, was_cancelled, String.wrap(prompt_text))

    def set_callback_begin_navigation(self, callback):
        awe_webview_set_callback_begin_navigation(self._ptr, callback)

    def set_callback_begin_loading(self, callback):
        awe_webview_set_callback_begin_loading(self._ptr, callback)

    def set_callback_finish_loading(self, callback):
        awe_webview_set_callback_finish_loading(self._ptr, callback)

    def set_callback_js_callback(self, callback):
        @_ffi.callback("void(awe_webview *, const awe_string *, const awe_string *, const awe_jsarray *)")
        def cbwrapper(caller, object_name, callback_name, arguments):
            caller = WebView(caller)
            object_name = String.unwrap(object_name)
            callback_name = String.unwrap(callback_name)
            arguments = JSArray(arguments)
            callback(caller, object_name, callback_name, arguments)
            
        awe_webview_set_callback_js_callback(self._ptr, cbwrapper)
        self._js_callback = cbwrapper

    def set_callback_receive_title(self, callback):
        awe_webview_set_callback_receive_title(self._ptr, callback)

    def set_callback_change_tooltip(self, callback):
        awe_webview_set_callback_change_tooltip(self._ptr, callback)

    def set_callback_change_cursor(self, callback):
        awe_webview_set_callback_change_cursor(self._ptr, callback)

    def set_callback_change_keyboard_focus(self, callback):
        @_ffi.callback("void(awe_webview *, bool)")
        def cbwrapper(caller, is_focused):
            caller = WebView(caller)
            is_focused = bool(is_focused)
            callback(caller, is_focused)
            
        awe_webview_set_callback_change_keyboard_focus(self._ptr, cbwrapper)
        self._change_keyboard_focus_callback = cbwrapper

    def set_callback_change_target_url(self, callback):
        awe_webview_set_callback_change_target_url(self._ptr, callback)

    def set_callback_open_external_link(self, callback):
        @_ffi.callback("void(awe_webview *, const awe_string *, const awe_string *)")
        def cbwrapper(caller, url, source):
            caller = WebView(caller)
            url = String.unwrap(url)
            source = String.unwrap(source)
            callback(caller, url, source)
            
        awe_webview_set_callback_open_external_link(self._ptr, cbwrapper)
        self._open_external_link_callback = cbwrapper

    def set_callback_request_download(self, callback):
        awe_webview_set_callback_request_download(self._ptr, callback)

    def set_callback_web_view_crashed(self, callback):
        awe_webview_set_callback_web_view_crashed(self._ptr, callback)

    def set_callback_plugin_crashed(self, callback):
        awe_webview_set_callback_plugin_crashed(self._ptr, callback)

    def set_callback_request_move(self, callback):
        awe_webview_set_callback_request_move(self._ptr, callback)

    def set_callback_get_page_contents(self, callback):
        awe_webview_set_callback_get_page_contents(self._ptr, callback)

    def set_callback_dom_ready(self, callback):
        awe_webview_set_callback_dom_ready(self._ptr, callback)

    def set_callback_request_file_chooser(self, callback):
        awe_webview_set_callback_request_file_chooser(self._ptr, callback)

    def set_callback_get_scroll_data(self, callback):
        awe_webview_set_callback_get_scroll_data(self._ptr, callback)

    def set_default_js_console_message_callback(self, logfunc = None):
        if logfunc is None:
            logfunc = log.info
        def log_js_console_message(caller, message, line_number, source):
            logfunc('{}({}): {}'.format(source, line_number, message))
        self.set_callback_js_console_message(log_js_console_message)

    def set_callback_js_console_message(self, callback):
        @_ffi.callback("void(awe_webview *, const awe_string *, int, const awe_string *)")        
        def cbwrapper(caller, message, line_number, source):
            caller = WebView(caller)
            message = String.unwrap(message)
            source = String.unwrap(source)
            callback(caller, message, line_number, source)
            
        awe_webview_set_callback_js_console_message(self._ptr, cbwrapper)
        self._js_console_message = cbwrapper

    def set_callback_get_find_results(self, callback):
        awe_webview_set_callback_get_find_results(self._ptr, callback)

    def set_callback_update_ime(self, callback):
        awe_webview_set_callback_update_ime(self._ptr, callback)

    def set_callback_show_context_menu(self, callback):
        awe_webview_set_callback_show_context_menu(self._ptr, callback)

    def set_callback_request_login(self, callback):
        awe_webview_set_callback_request_login(self._ptr, callback)

    def set_callback_change_history(self, callback):
        awe_webview_set_callback_change_history(self._ptr, callback)

    def set_callback_finish_resize(self, callback):
        awe_webview_set_callback_finish_resize(self._ptr, callback)

    def set_callback_show_javascript_dialog(self, callback):
        awe_webview_set_callback_show_javascript_dialog(self._ptr, callback)

    def set_callback_resource_request(self, callback):
        awe_webview_set_callback_resource_request(self._ptr, callback)

    def set_callback_resource_response(self, callback):
        awe_webview_set_callback_resource_response(self._ptr, callback)

################################################################################

class JSValue(object):
    @classmethod
    def create_null_value(cls):
        return cls(awe_jsvalue_create_null_value(), managed = True)

    @classmethod
    def create_bool_value(cls, value):
        return cls(awe_jsvalue_create_bool_value(value), managed = True)

    @classmethod
    def create_integer_value(cls, value):
        return cls(awe_jsvalue_create_integer_value(value), managed = True)

    @classmethod
    def create_double_value(cls, value):
        return cls(awe_jsvalue_create_double_value(value), managed = True)

    @classmethod
    def create_string_value(cls, value):
        return cls(awe_jsvalue_create_string_value(String.wrap(value)), managed = True)

    @classmethod
    def create_object_value(cls, value):
        assert isinstance(value, JSObject)
        return cls(awe_jsvalue_create_object_value(value._ptr), managed = True)

    @classmethod
    def create_array_value(cls, value):
        assert isinstance(value, JSArray)
        return cls(awe_jsvalue_create_array_value(value._ptr), managed = True)
    
    @classmethod
    def create(cls, value):
        if isinstance(value, cls):
            return value 
        elif value is None:
            return cls.create_null_value()
        elif isinstance(value, bool):
            return cls.create_bool_value(value)
        elif isinstance(value, int):
            return cls.create_integer_value(value)
        elif isinstance(value, float):
            return cls.create_double_value(value)
        elif isinstance(value, str):
            return cls.create_string_value(value)
        elif isinstance(value, JSObject):
            return cls.create_object_value(value)
        elif isinstance(value, JSArray):
            return cls.create_array_value(value)
        else:
            raise ValueError, "don't know how to convert {!r}".format(value)

    def __init__(self, ptr, managed = False):
        assert _ffi.typeof(ptr) is _ffi.typeof("awe_jsvalue*") #@UndefinedVariable
        if managed:
            ptr = _ffi.gc(ptr, awe_jsvalue_destroy) #@UndefinedVariable
        self._ptr = ptr

    def destroy(self):
        self._ptr = None

    def get_type(self):
        return awe_jsvalue_get_type(self._ptr)

    def to_string(self):
        return String.unwrap(awe_jsvalue_to_string(self._ptr))

    def to_integer(self):
        return awe_jsvalue_to_integer(self._ptr)

    def to_double(self):
        return awe_jsvalue_to_double(self._ptr)

    def to_boolean(self):
        return awe_jsvalue_to_boolean(self._ptr)

    def get_array(self):
        return JSArray(awe_jsvalue_get_array(self._ptr))

    def get_object(self):
        return JSObject(awe_jsvalue_get_object(self._ptr))
    
    def get_value(self):
        return {
            JSVALUE_TYPE_NULL: lambda: None,
            JSVALUE_TYPE_STRING: self.to_string,
            JSVALUE_TYPE_INTEGER: self.to_integer,
            JSVALUE_TYPE_DOUBLE: self.to_double,
            JSVALUE_TYPE_BOOLEAN: self.to_boolean,
            JSVALUE_TYPE_ARRAY: self.get_array,
            JSVALUE_TYPE_OBJECT: self.get_object,
        }[self.get_type()]()

    def to_native(self):
        value = self.get_value()
        if isinstance(value, (JSArray, JSObject)):
            value = value.to_native()
        return value
    
    @classmethod
    def from_native(cls, value):
        if isinstance(value, (tuple, list)):
            value = JSArray.from_native(value)
        elif isinstance(value, dict):
            value = JSObject.from_native(value)
        return cls.create(value)
    
################################################################################

class JSArray(object):
    def __init__(self, ptr, managed = False):
        assert _ffi.typeof(ptr) is _ffi.typeof("awe_jsarray*") #@UndefinedVariable
        if managed:
            ptr = _ffi.gc(ptr, awe_jsarray_destroy) #@UndefinedVariable
        self._ptr = ptr
    
    @classmethod
    def create(cls, jsvalue_array):
        values = [JSValue.create(v)._ptr for v in jsvalue_array]
        return cls(awe_jsarray_create(values, len(jsvalue_array)), managed = True)

    def destroy(self):
        self._ptr = None

    def get_size(self):
        return awe_jsarray_get_size(self._ptr)

    def get_element(self, index):
        return JSValue(awe_jsarray_get_element(self._ptr, index))

    def to_native(self):
        return [self.get_element(index).to_native() 
            for index in range(self.get_size())] 
        
    @classmethod
    def from_native(cls, values):
        return cls.create([JSValue.from_native(e) for e in values])

################################################################################

class JSObject(object):
    def __init__(self, ptr, managed = False):
        assert _ffi.typeof(ptr) is _ffi.typeof("awe_jsobject*") #@UndefinedVariable
        if managed:
            ptr = _ffi.gc(ptr, awe_jsobject_destroy) #@UndefinedVariable
        self._ptr = ptr
    
    @classmethod
    def create(cls):
        return JSObject(awe_jsobject_create(), managed = True)

    def destroy(self):
        self._ptr = None

    def has_property(self, property_name):
        return awe_jsobject_has_property(self._ptr, String.wrap(property_name))

    def get_property(self, property_name):
        return JSValue(awe_jsobject_get_property(self._ptr, String.wrap(property_name)))

    def set_property(self, property_name, value):
        awe_jsobject_set_property(self._ptr, String.wrap(property_name), 
            JSValue.create(value)._ptr)

    def get_size(self):
        return awe_jsobject_get_size(self._ptr)

    def get_keys(self):
        return JSArray(awe_jsobject_get_keys(self._ptr))
    
    def to_native(self):
        result = {}
        for key in self.get_keys().to_native():
            result[key] = self.get_property(key).to_native()
        return result

    @classmethod
    def from_native(cls, value):
        obj = cls.create()
        for key, val in value.items():
            obj.set_property(key, JSValue.from_native(val))
        return obj

################################################################################

class RenderBuffer(object):
    def __init__(self, webview):
        self._ptr = awe_webview_render(webview._ptr)
    
    def get_width(self):
        return awe_renderbuffer_get_width (self._ptr)
    
    def get_height(self):
        return awe_renderbuffer_get_height (self._ptr)
    
    def get_rowspan(self):
        return awe_renderbuffer_get_rowspan (self._ptr)
    
    def get_buffer(self):
        return awe_renderbuffer_get_buffer (self._ptr)
    
    def copy_to(self, dest_buffer, dest_rowspan, dest_depth, convert_to_rgba, 
        flip_y):
        awe_renderbuffer_copy_to (self._ptr, dest_buffer, dest_rowspan,
            dest_depth, convert_to_rgba, flip_y)
    
    def copy_to_float(self, dest_buffer):
        awe_renderbuffer_copy_to_float (self._ptr, dest_buffer)
        
    def save_to_png(self, file_path, preserve_transparency):
        return awe_renderbuffer_save_to_png (self._ptr, String.wrap(file_path), 
            preserve_transparency)
        
    def save_to_jpeg(self, file_path, quality):
        return awe_renderbuffer_save_to_jpeg (self._ptr, String.wrap(file_path),
            quality)
    
    def get_alpha_at_point(self, x, y): 
        return awe_renderbuffer_get_alpha_at_point (self._ptr, x, y)
    
    def flush_alpha(self):
        awe_renderbuffer_flush_alpha (self._ptr)

################################################################################

class ResourceResponse(object):
    # this class makes no sense yet
    
    def create(self, buf, mime_type):
        return awe_resource_response_create(self._ptr, buf, String.wrap(mime_type))

    def create_from_file(self):
        return awe_resource_response_create_from_file(self._ptr)

################################################################################

class ResourceRequest(object):
    # this class makes no sense yet
    
    def cancel(self):
        awe_resource_request_cancel(self._ptr)

    def get_url(self):
        return String.unwrap(awe_resource_request_get_url(self._ptr))

    def get_method(self):
        return String.unwrap(awe_resource_request_get_method(self._ptr))

    def set_method(self, method):
        awe_resource_request_set_method(self._ptr, String.wrap(method))

    def get_referrer(self):
        return String.unwrap(awe_resource_request_get_referrer(self._ptr))

    def set_referrer(self, referrer):
        awe_resource_request_set_referrer(self._ptr, String.wrap(referrer))

    def get_extra_headers(self):
        return String.unwrap(awe_resource_request_get_extra_headers(self._ptr))

    def set_extra_headers(self, headers):
        awe_resource_request_set_extra_headers(self._ptr, String.wrap(headers))

    def append_extra_header(self, name, value):
        awe_resource_request_append_extra_header(self._ptr, String.wrap(name), String.wrap(value))

    def get_num_upload_elements(self):
        return awe_resource_request_get_num_upload_elements(self._ptr)

    def get_upload_element(self, idx):
        return awe_resource_request_get_upload_element(self._ptr, idx)

    def clear_upload_elements(self):
        awe_resource_request_clear_upload_elements(self._ptr)

    def append_upload_file_path(self, file_path):
        awe_resource_request_append_upload_file_path(self._ptr, String.wrap(file_path))

    def append_upload_bytes(self, data):
        awe_resource_request_append_upload_bytes(self._ptr, String.wrap(data))
    
################################################################################

class UploadElement(object):
    # this class makes no sense yet
    
    def is_file_path(self):        
        return awe_upload_element_is_file_path(self._ptr)

    def is_bytes(self):
        return awe_upload_element_is_bytes(self._ptr)

    def get_bytes(self):
        return String.unwrap(awe_upload_element_get_bytes(self._ptr))

    def get_file_path(self):
        return String.unwrap(awe_upload_element_get_file_path(self._ptr))

################################################################################

class HistoryQueryResult(object):
    # this class makes no sense yet
    
    def destroy(self):
        awe_history_query_result_destroy(self._ptr)

    def get_size(self):
        return awe_history_query_result_get_size(self._ptr)

    def get_entry_at_index(self, idx):
        return awe_history_query_result_get_entry_at_index(self._ptr, idx)

################################################################################

class HistoryEntry(object):
    # this class makes no sense yet
    
    def destroy(self):
        awe_history_entry_destroy(self._ptr)

    def get_url(self):
        return String.unwrap(awe_history_entry_get_url(self._ptr))

    def get_title(self):
        return String.unwrap(awe_history_entry_get_title(self._ptr))

    def get_visit_time(self):
        return awe_history_entry_get_visit_time(self._ptr)

    def get_visit_count(self):
        return awe_history_entry_get_visit_count(self._ptr)

################################################################################

def WebKeyboardEvent():
    return _ffi.new('awe_webkeyboardevent*')
