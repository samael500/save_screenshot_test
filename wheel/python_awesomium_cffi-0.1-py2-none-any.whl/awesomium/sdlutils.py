from __future__ import (print_function, division, absolute_import)

import sdl
from . import _awesomium as awe
from . import keycodes, proxy

__all__ = [
]

################################################################################

# compatibility functions to deal with events from python-sdl-cffi

KEYMAP_SDL2WEB = {
    sdl.SDLK_BACKSPACE: keycodes.AK_BACK,
    sdl.SDLK_TAB: keycodes.AK_TAB,
    sdl.SDLK_CLEAR: keycodes.AK_CLEAR,
    sdl.SDLK_RETURN: keycodes.AK_RETURN,
    sdl.SDLK_PAUSE: keycodes.AK_PAUSE,
    sdl.SDLK_ESCAPE: keycodes.AK_ESCAPE,
    sdl.SDLK_SPACE: keycodes.AK_SPACE,
    sdl.SDLK_EXCLAIM: keycodes.AK_1,
    sdl.SDLK_QUOTEDBL: keycodes.AK_2,
    sdl.SDLK_HASH: keycodes.AK_3,
    sdl.SDLK_DOLLAR: keycodes.AK_4,
    sdl.SDLK_AMPERSAND: keycodes.AK_7,
    sdl.SDLK_QUOTE: keycodes.AK_OEM_7,
    sdl.SDLK_LEFTPAREN: keycodes.AK_9,
    sdl.SDLK_RIGHTPAREN: keycodes.AK_0,
    sdl.SDLK_ASTERISK: keycodes.AK_8,
    sdl.SDLK_PLUS: keycodes.AK_OEM_PLUS,
    sdl.SDLK_COMMA: keycodes.AK_OEM_COMMA,
    sdl.SDLK_MINUS: keycodes.AK_OEM_MINUS,
    sdl.SDLK_PERIOD: keycodes.AK_OEM_PERIOD,
    sdl.SDLK_SLASH: keycodes.AK_OEM_2,
    sdl.SDLK_0: keycodes.AK_0,
    sdl.SDLK_1: keycodes.AK_1,
    sdl.SDLK_2: keycodes.AK_2,
    sdl.SDLK_3: keycodes.AK_3,
    sdl.SDLK_4: keycodes.AK_4,
    sdl.SDLK_5: keycodes.AK_5,
    sdl.SDLK_6: keycodes.AK_6,
    sdl.SDLK_7: keycodes.AK_7,
    sdl.SDLK_8: keycodes.AK_8,
    sdl.SDLK_9: keycodes.AK_9,
    sdl.SDLK_COLON: keycodes.AK_OEM_1,
    sdl.SDLK_SEMICOLON: keycodes.AK_OEM_1,
    sdl.SDLK_LESS: keycodes.AK_OEM_COMMA,
    sdl.SDLK_EQUALS: keycodes.AK_OEM_PLUS,
    sdl.SDLK_GREATER: keycodes.AK_OEM_PERIOD,
    sdl.SDLK_QUESTION: keycodes.AK_OEM_2,
    sdl.SDLK_AT: keycodes.AK_2,
    sdl.SDLK_LEFTBRACKET: keycodes.AK_OEM_4,
    sdl.SDLK_BACKSLASH: keycodes.AK_OEM_5,
    sdl.SDLK_RIGHTBRACKET: keycodes.AK_OEM_6,
    sdl.SDLK_CARET: keycodes.AK_6,
    sdl.SDLK_UNDERSCORE: keycodes.AK_OEM_MINUS,
    sdl.SDLK_BACKQUOTE: keycodes.AK_OEM_3,
    sdl.SDLK_a: keycodes.AK_A,
    sdl.SDLK_b: keycodes.AK_B,
    sdl.SDLK_c: keycodes.AK_C,
    sdl.SDLK_d: keycodes.AK_D,
    sdl.SDLK_e: keycodes.AK_E,
    sdl.SDLK_f: keycodes.AK_F,
    sdl.SDLK_g: keycodes.AK_G,
    sdl.SDLK_h: keycodes.AK_H,
    sdl.SDLK_i: keycodes.AK_I,
    sdl.SDLK_j: keycodes.AK_J,
    sdl.SDLK_k: keycodes.AK_K,
    sdl.SDLK_l: keycodes.AK_L,
    sdl.SDLK_m: keycodes.AK_M,
    sdl.SDLK_n: keycodes.AK_N,
    sdl.SDLK_o: keycodes.AK_O,
    sdl.SDLK_p: keycodes.AK_P,
    sdl.SDLK_q: keycodes.AK_Q,
    sdl.SDLK_r: keycodes.AK_R,
    sdl.SDLK_s: keycodes.AK_S,
    sdl.SDLK_t: keycodes.AK_T,
    sdl.SDLK_u: keycodes.AK_U,
    sdl.SDLK_v: keycodes.AK_V,
    sdl.SDLK_w: keycodes.AK_W,
    sdl.SDLK_x: keycodes.AK_X,
    sdl.SDLK_y: keycodes.AK_Y,
    sdl.SDLK_z: keycodes.AK_Z,
    sdl.SDLK_DELETE: keycodes.AK_DELETE,
    sdl.SDLK_KP_0: keycodes.AK_NUMPAD0,
    sdl.SDLK_KP_1: keycodes.AK_NUMPAD1,
    sdl.SDLK_KP_2: keycodes.AK_NUMPAD2,
    sdl.SDLK_KP_3: keycodes.AK_NUMPAD3,
    sdl.SDLK_KP_4: keycodes.AK_NUMPAD4,
    sdl.SDLK_KP_5: keycodes.AK_NUMPAD5,
    sdl.SDLK_KP_6: keycodes.AK_NUMPAD6,
    sdl.SDLK_KP_7: keycodes.AK_NUMPAD7,
    sdl.SDLK_KP_8: keycodes.AK_NUMPAD8,
    sdl.SDLK_KP_9: keycodes.AK_NUMPAD9,
    sdl.SDLK_KP_PERIOD: keycodes.AK_DECIMAL,
    sdl.SDLK_KP_DIVIDE: keycodes.AK_DIVIDE,
    sdl.SDLK_KP_MULTIPLY: keycodes.AK_MULTIPLY,
    sdl.SDLK_KP_MINUS: keycodes.AK_SUBTRACT,
    sdl.SDLK_KP_PLUS: keycodes.AK_ADD,
    sdl.SDLK_KP_ENTER: keycodes.AK_SEPARATOR,
    sdl.SDLK_KP_EQUALS: keycodes.AK_UNKNOWN,
    sdl.SDLK_UP: keycodes.AK_UP,
    sdl.SDLK_DOWN: keycodes.AK_DOWN,
    sdl.SDLK_RIGHT: keycodes.AK_RIGHT,
    sdl.SDLK_LEFT: keycodes.AK_LEFT,
    sdl.SDLK_INSERT: keycodes.AK_INSERT,
    sdl.SDLK_HOME: keycodes.AK_HOME,
    sdl.SDLK_END: keycodes.AK_END,
    sdl.SDLK_PAGEUP: keycodes.AK_PRIOR,
    sdl.SDLK_PAGEDOWN: keycodes.AK_NEXT,
    sdl.SDLK_F1: keycodes.AK_F1,
    sdl.SDLK_F2: keycodes.AK_F2,
    sdl.SDLK_F3: keycodes.AK_F3,
    sdl.SDLK_F4: keycodes.AK_F4,
    sdl.SDLK_F5: keycodes.AK_F5,
    sdl.SDLK_F6: keycodes.AK_F6,
    sdl.SDLK_F7: keycodes.AK_F7,
    sdl.SDLK_F8: keycodes.AK_F8,
    sdl.SDLK_F9: keycodes.AK_F9,
    sdl.SDLK_F10: keycodes.AK_F10,
    sdl.SDLK_F11: keycodes.AK_F11,
    sdl.SDLK_F12: keycodes.AK_F12,
    sdl.SDLK_F13: keycodes.AK_F13,
    sdl.SDLK_F14: keycodes.AK_F14,
    sdl.SDLK_F15: keycodes.AK_F15,
    sdl.SDLK_NUMLOCKCLEAR: keycodes.AK_NUMLOCK,
    sdl.SDLK_CAPSLOCK: keycodes.AK_CAPITAL,
    sdl.SDLK_SCROLLLOCK: keycodes.AK_SCROLL,
    sdl.SDLK_RSHIFT: keycodes.AK_RSHIFT,
    sdl.SDLK_LSHIFT: keycodes.AK_LSHIFT,
    sdl.SDLK_RCTRL: keycodes.AK_RCONTROL,
    sdl.SDLK_LCTRL: keycodes.AK_LCONTROL,
    sdl.SDLK_RALT: keycodes.AK_RMENU,
    sdl.SDLK_LALT: keycodes.AK_LMENU,
    #sdl.SDLK_RMETA: keycodes.AK_LWIN,
    #sdl.SDLK_LMETA: keycodes.AK_RWIN,
    #sdl.SDLK_LSUPER: keycodes.AK_LWIN,
    #sdl.SDLK_RSUPER: keycodes.AK_RWIN,
    sdl.SDLK_MODE: keycodes.AK_MODECHANGE,
    #sdl.SDLK_COMPOSE: keycodes.AK_ACCEPT,
    sdl.SDLK_HELP: keycodes.AK_HELP,
    #sdl.SDLK_PRINT: keycodes.AK_SNAPSHOT,
    sdl.SDLK_SYSREQ: keycodes.AK_EXECUTE
}

def web_key_from_sdl_key(key):
    return KEYMAP_SDL2WEB.get(key, keycodes.AK_UNKNOWN)

def web_mod_from_sdl_mod(modkey):
    modifiers = 0
    if modkey & sdl.KMOD_ALT:
        modifiers |= awe.AWE_WKM_ALT_KEY
    if modkey & sdl.KMOD_CTRL:
        modifiers |= awe.AWE_WKM_CONTROL_KEY
    if modkey & sdl.KMOD_GUI:
        modifiers |= awe.AWE_WKM_META_KEY
    if modkey & sdl.KMOD_SHIFT:
        modifiers |= awe.AWE_WKM_SHIFT_KEY
    if modkey & sdl.KMOD_NUM:
        modifiers |= awe.AWE_WKM_IS_KEYPAD
    return modifiers

def init_web_key_event_from_sdl_key_event(web_event, key_event):
    web_event.virtual_key_code = web_key_from_sdl_key(key_event.key.keysym.sym)
    web_event.native_key_code = key_event.key.keysym.scancode
    web_event.modifiers = web_mod_from_sdl_mod(key_event.key.keysym.mod)

def handle_sdl_key_down(webview, event):
    key_event = proxy.WebKeyboardEvent()
    key_event.type = awe.AWE_WKT_KEYDOWN
    init_web_key_event_from_sdl_key_event(key_event, event)
    webview.inject_keyboard_event(key_event)
    
    sym = event.key.keysym.sym
    if sym < 32:
        key_event.type = awe.AWE_WKT_CHAR
        key_event.text[0] = sym
        key_event.unmodified_text[0] = sym
        key_event.virtual_key_code = sym
        key_event.native_key_code = sym
        webview.inject_keyboard_event(key_event)
    
    return True

def handle_sdl_key_up(webview, event):
    key_event = proxy.WebKeyboardEvent()
    key_event.type = awe.AWE_WKT_KEYUP
    init_web_key_event_from_sdl_key_event(key_event, event)
    webview.inject_keyboard_event(key_event)
    return True

def handle_sdl_text_input(webview, event):
    key_event = proxy.WebKeyboardEvent()
    key_event.type = awe.AWE_WKT_CHAR

    text = proxy._ffi.string(event.text.text).decode('utf-8')
    
    char = ord(text[0])
    if (char & 0xFF80) == 0:
        char = char & 0x7F
    
    if char > 0xffff:
        # doesn't fit in u16 
        return
    
    key_event.text[0] = char
    key_event.unmodified_text[0] = char
    key_event.virtual_key_code = char
    key_event.native_key_code = char
    
    webview.inject_keyboard_event(key_event)
    
    return True

def handle_sdl_key_event(webview, event):
    if event.type == sdl.SDL_KEYDOWN:
        return handle_sdl_key_down(webview, event)
    elif event.type == sdl.SDL_KEYUP:
        return handle_sdl_key_up(webview, event)
    elif event.type == sdl.SDL_TEXTINPUT:
        return handle_sdl_text_input(webview, event)
    return False
