# code generator - only required at build time
from __future__ import (print_function, division, absolute_import)

import os
from autobind import AutoBind

THISDIR = os.path.dirname(__file__)
AWESOMIUM_PATH = os.path.abspath(os.path.join(
    THISDIR, '..', 'external', 'awesomium'))
CDEF_PATH = os.path.join(AWESOMIUM_PATH, 'include', 'Awesomium')
BIN_PATH = os.path.abspath(os.path.join(
    AWESOMIUM_PATH, 'build', 'bin', 'release'))
INCLUDE_PATH = os.path.abspath(os.path.join(AWESOMIUM_PATH, 'include'))
LIB_PATH = BIN_PATH
LIBNAME = 'awesomium-1.6.5'

VERIFY_SOURCE = """
#include <stdbool.h>
#include "Awesomium/awesomium_capi.h"
"""

os.environ['LD_LIBRARY_PATH'] = BIN_PATH

autobind = AutoBind(options=dict(
    CDEF_PATH = CDEF_PATH,
    CDEF_FILES = [ 
        '../../../../defs/prefix.h',
        'awesomium_capi.h',
    ],
    DEFINES_BLACKLIST = [
    ],
    DEFINES = [],
    PRIVATE_SYMBOLS = [
    ],
    AUTOCHECK_BLACKLIST = [
    ],
    REPLACES = [
        ('_OSMExport', ''),
        ('1 << 0', '0x01'),
        ('1 << 1', '0x02'),
        ('1 << 2', '0x04'),
        ('1 << 3', '0x08'),
        ('1 << 4', '0x10'),
        ('1 << 5', '0x20'),
        #('SDLCALL', ''),
    ],
    #LIBNAME = LIBNAME,
    VERIFY_SOURCE = VERIFY_SOURCE,
    AUTOMANGLE = False,
    VERIFY_OPTIONS = dict(
        extra_link_args = [
        '-fPIC',
        ],
        libraries = [LIBNAME],
        include_dirs = [INCLUDE_PATH],
        library_dirs = [LIB_PATH],
    ),
    PYPREDEFS = os.path.join(THISDIR, '..', 'predefs', 'awesomium.pypredef'),
    OUTMODULE = os.path.join(THISDIR, '_awesomium.py'),
    STRIP = True,
    DEBUGOUT = False
))

################################################################################

if __name__ == '__main__':
    autobind.build()
