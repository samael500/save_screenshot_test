
# this file is auto-generated. do not edit.
from __future__ import (print_function, division, absolute_import)

from cffi import FFI

UNMANGLED_EXPORTS = [

]

EXPORTS = [
"awe_webview_unfocus",
"awe_webview_reload",
"AWE_CUR_SOUTHEAST_RESIZE",
"awe_renderbuffer_get_width",
"awe_webview_execute_javascript_with_result",
"AWE_DIALOG_HAS_MESSAGE",
"AWE_CAN_DELETE",
"awe_jsobject_get_property",
"AWE_CAN_UNDO",
"awe_jsvalue_create_string_value",
"AWE_CUR_NORTH_PANNING",
"awe_jsvalue_create_null_value",
"awe_webcore_get_base_directory",
"awe_webview_call_javascript_function",
"awe_resource_request_set_method",
"AWE_CUR_ZOOM_OUT",
"JSVALUE_TYPE_STRING",
"awe_webview_add_header_rewrite_rule",
"awe_webview_load_html",
"AWE_CUR_NORTHWEST_RESIZE",
"awe_jsvalue_get_type",
"awe_webview_confirm_ime_composition",
"awe_webcore_set_suppress_printer_dialog",
"awe_webview_find",
"awe_webview_inject_mouse_down",
"awe_webcore_delete_cookie",
"AWE_CAN_COPY",
"awe_upload_element_get_bytes",
"AWE_WKT_CHAR",
"awe_jsarray_get_element",
"JSVALUE_TYPE_NULL",
"AWE_CUR_NORTHWEST_SOUTHEAST_RESIZE",
"awe_string_destroy",
"AWE_CUR_HELP",
"awe_jsvalue_to_integer",
"awe_webcore_set_cookie",
"AWE_WKT_KEYDOWN",
"awe_webview_set_callback_request_file_chooser",
"AWE_IME_COMPLETE_COMPOSITION",
"awe_webview_set_header_definition",
"awe_resource_request_get_num_upload_elements",
"awe_history_query_result_get_size",
"AWE_CUR_CELL",
"awe_webview_close_javascript_dialog",
"AWE_CUR_WEST_PANNING",
"AWE_MEDIA_STATE_LOOP",
"awe_webcore_set_base_directory",
"awe_history_entry_get_title",
"awe_webview_activate_ime",
"AWE_LL_NORMAL",
"JSVALUE_TYPE_INTEGER",
"AWE_DIALOG_HAS_CANCEL_BUTTON",
"AWE_CUR_WEST_RESIZE",
"AWE_MEDIA_STATE_CAN_SAVE",
"awe_webview_print",
"AWE_IME_DISABLE",
"awe_webview_login",
"AWE_UFM_BLACKLIST",
"awe_jsarray_destroy",
"AWE_CUR_CONTEXT_MENU",
"AWE_DIALOG_HAS_PROMPT_FIELD",
"awe_jsarray_get_size",
"AWE_MEDIA_TYPE_AUDIO",
"AWE_MEDIA_TYPE_VIDEO",
"awe_webview_set_callback_get_find_results",
"AWE_WKM_IS_KEYPAD",
"awe_webcore_clear_cache",
"awe_webview_choose_file",
"AWE_LL_VERBOSE",
"AWE_LL_NONE",
"JSVALUE_TYPE_OBJECT",
"awe_webview_get_zoom",
"AWE_UFM_NONE",
"AWE_MEDIA_STATE_HAS_AUDIO",
"awe_resource_request_append_extra_header",
"awe_webview_set_callback_update_ime",
"AWE_WKT_KEYUP",
"JSVALUE_TYPE_BOOLEAN",
"awe_renderbuffer_get_buffer",
"awe_history_entry_get_visit_time",
"AWE_WKM_META_KEY",
"awe_resource_request_set_referrer",
"AWE_CUR_COLUMN_RESIZE",
"AWE_CUR_SOUTHWEST_RESIZE",
"AWE_CUR_EAST_RESIZE",
"awe_webview_paste",
"awe_webview_set_callback_resource_request",
"awe_webview_request_scroll_data",
"AWE_CUR_ZOOM_IN",
"awe_jsobject_destroy",
"AWE_MB_RIGHT",
"AWE_CUR_POINTER",
"awe_jsobject_create",
"AWE_CUR_MOVE",
"AWE_MEDIA_STATE_ERROR",
"awe_string_create_from_utf16",
"awe_webview_is_transparent",
"AWE_CUR_NORTHEAST_PANNING",
"awe_webview_set_callback_resource_response",
"AWE_CUR_NORTHEAST_RESIZE",
"awe_webview_load_url",
"awe_webview_set_callback_request_login",
"AWE_CUR_SOUTHWEST_PANNING",
"AWE_CUR_NO_DROP",
"awe_jsarray_create",
"JSVALUE_TYPE_DOUBLE",
"awe_webview_set_callback_get_page_contents",
"awe_webview_set_callback_begin_loading",
"awe_webview_set_callback_show_javascript_dialog",
"awe_renderbuffer_get_alpha_at_point",
"awe_string_to_utf8",
"awe_webview_set_zoom",
"AWE_CAN_CUT",
"awe_webview_set_object_callback",
"AWE_WKM_ALT_KEY",
"awe_resource_response_create",
"awe_jsvalue_get_array",
"awe_webview_inject_keyboard_event",
"awe_webview_render",
"awe_history_entry_get_url",
"AWE_CUR_SOUTHEAST_PANNING",
"awe_webview_inject_mouse_wheel",
"AWE_CUR_COPY",
"JSVALUE_TYPE_ARRAY",
"awe_resource_request_get_upload_element",
"awe_webview_destroy_object",
"awe_string_empty",
"awe_webview_get_history_back_count",
"awe_webview_create_object",
"AWE_DIALOG_HAS_OK_BUTTON",
"AWE_CUR_CROSS",
"AWE_CUR_PROGRESS",
"awe_webview_reset_zoom",
"AWE_CUR_SOUTH_PANNING",
"awe_webview_set_callback_begin_navigation",
"awe_webview_cut",
"AWE_MEDIA_TYPE_IMAGE",
"awe_webview_is_dirty",
"AWE_CUR_VERTICAL_TEXT",
"awe_webview_get_dirty_bounds",
"AWE_MB_LEFT",
"awe_jsobject_has_property",
"awe_renderbuffer_flush_alpha",
"AWE_CUR_EAST_PANNING",
"awe_webcore_query_history",
"awe_upload_element_is_file_path",
"awe_webcore_clear_cookies",
"awe_webview_go_to_history_offset",
"awe_resource_request_cancel",
"awe_webview_inject_mouse_move",
"awe_webview_resume_rendering",
"awe_renderbuffer_get_rowspan",
"awe_renderbuffer_save_to_jpeg",
"awe_webview_focus",
"awe_webview_set_callback_change_history",
"AWE_MB_MIDDLE",
"awe_webview_set_object_property",
"awe_webview_inject_mouse_up",
"awe_jsvalue_to_boolean",
"awe_resource_request_get_referrer",
"awe_renderbuffer_copy_to",
"awe_webcore_initialize_default",
"awe_webview_load_file",
"awe_renderbuffer_save_to_png",
"AWE_CUR_EASTWEST_RESIZE",
"awe_webview_get_zoom_for_host",
"awe_upload_element_is_bytes",
"AWE_MEDIA_STATE_MUTED",
"AWE_WKM_SHIFT_KEY",
"awe_resource_request_get_url",
"AWE_CUR_ROW_RESIZE",
"AWE_CUR_HAND",
"awe_resource_request_append_upload_bytes",
"awe_webview_set_ime_composition",
"AWE_CAN_SELECT_ALL",
"awe_webview_get_history_forward_count",
"awe_webview_set_url_filtering_mode",
"awe_resource_request_get_extra_headers",
"awe_renderbuffer_copy_to_float",
"awe_webview_destroy",
"awe_resource_response_create_from_file",
"awe_webcore_are_plugins_enabled",
"awe_webview_stop_find",
"awe_webview_set_callback_dom_ready",
"awe_webcore_create_webview",
"awe_webview_set_callback_finish_loading",
"awe_resource_request_set_extra_headers",
"awe_resource_request_append_upload_file_path",
"awe_webview_set_callback_change_keyboard_focus",
"awe_jsvalue_to_string",
"awe_history_query_result_get_entry_at_index",
"awe_renderbuffer_get_height",
"awe_jsvalue_create_array_value",
"AWE_CUR_ALIAS",
"awe_string_get_utf16",
"AWE_CUR_NORTHEAST_SOUTHWEST_RESIZE",
"awe_webview_set_callback_show_context_menu",
"awe_jsvalue_create_bool_value",
"AWE_CUR_NORTHWEST_PANNING",
"awe_is_child_process",
"awe_resource_request_clear_upload_elements",
"AWE_CAN_EDIT_NOTHING",
"awe_webview_set_callback_js_console_message",
"AWE_CUR_NOT_ALLOWED",
"awe_webview_remove_header_rewrite_rules_by_definition_name",
"AWE_CUR_NORTH_RESIZE",
"awe_child_process_main",
"awe_webview_copy",
"awe_webview_stop",
"awe_webview_add_url_filter",
"awe_webview_get_url",
"awe_string_create_from_ascii",
"awe_upload_element_get_file_path",
"awe_jsvalue_get_object",
"awe_webview_is_resizing",
"awe_jsobject_get_size",
"awe_jsobject_get_keys",
"awe_string_create_from_utf8",
"awe_webview_execute_javascript",
"awe_webview_set_callback_get_scroll_data",
"AWE_CUR_IBEAM",
"AWE_IME_MOVE_WINDOW",
"awe_webview_set_callback_receive_title",
"awe_webview_translate_page",
"awe_webview_set_transparent",
"AWE_MEDIA_STATE_NONE",
"AWE_CAN_REDO",
"awe_jsvalue_create_object_value",
"AWE_CAN_PASTE",
"awe_webview_resize",
"awe_webview_is_loading_page",
"AWE_CUR_NORTHSOUTH_RESIZE",
"awe_webview_set_callback_change_tooltip",
"AWE_CUR_SOUTH_RESIZE",
"awe_webview_clear_all_url_filters",
"AWE_UFM_WHITELIST",
"awe_jsvalue_create_integer_value",
"awe_jsvalue_create_double_value",
"awe_webcore_initialize",
"awe_history_query_result_destroy",
"AWE_WKM_CONTROL_KEY",
"awe_webview_set_callback_open_external_link",
"awe_string_get_length",
"awe_jsvalue_destroy",
"awe_webcore_get_cookies",
"AWE_MEDIA_TYPE_NONE",
"awe_webview_pause_rendering",
"awe_webcore_set_custom_response_page",
"awe_webview_cancel_ime_composition",
"awe_webview_set_callback_js_callback",
"awe_jsobject_set_property",
"awe_webview_copy_image_at",
"awe_webview_remove_header_rewrite_rule",
"awe_resource_request_get_method",
"awe_webview_set_callback_change_cursor",
"AWE_CUR_MIDDLE_PANNING",
"awe_webview_select_all",
"awe_history_entry_get_visit_count",
"awe_string_to_wide",
"awe_webcore_update",
"awe_webview_set_callback_plugin_crashed",
"AWE_CUR_NONE",
"AWE_WKM_IS_AUTOREPEAT",
"awe_history_entry_destroy",
"awe_webview_cancel_login",
"awe_webview_set_callback_request_move",
"awe_webview_set_callback_request_download",
"awe_webview_set_callback_web_view_crashed",
"awe_jsvalue_to_double",
"AWE_MEDIA_STATE_PAUSED",
"awe_string_create_from_wide",
"awe_webview_set_callback_change_target_url",
"awe_webcore_shutdown",
"awe_webview_set_callback_finish_resize",
"AWE_CUR_CUSTOM",
"AWE_CUR_WAIT",

]

INTERNAL_EXPORTS = [
'_ffi',
'EXPORTS',
'UNMANGLED_EXPORTS',
]

__all__ = EXPORTS + UNMANGLED_EXPORTS + INTERNAL_EXPORTS

from .internal import *

_LIB = load_lib("""
typedef _Bool bool;
typedef unsigned short wchar16;
typedef long long int64;
typedef struct _awe_webview awe_webview;
typedef struct _awe_jsvalue awe_jsvalue;
typedef struct _awe_jsarray awe_jsarray;
typedef struct _awe_jsobject awe_jsobject;
typedef struct _awe_renderbuffer awe_renderbuffer;
typedef struct _awe_header_definition awe_header_definition;
typedef struct _awe_resource_response awe_resource_response;
typedef struct _awe_resource_request awe_resource_request;
typedef struct _awe_upload_element awe_upload_element;
typedef struct _awe_string awe_string;
typedef struct _awe_history_query_result awe_history_query_result;
typedef struct _awe_history_entry awe_history_entry;
typedef enum _awe_loglevel
{
AWE_LL_NONE,
AWE_LL_NORMAL,
AWE_LL_VERBOSE
} awe_loglevel;
typedef enum _awe_mousebutton
{
AWE_MB_LEFT,
AWE_MB_MIDDLE,
AWE_MB_RIGHT
} awe_mousebutton;
typedef enum _awe_url_filtering_mode
{
AWE_UFM_NONE,
AWE_UFM_BLACKLIST,
AWE_UFM_WHITELIST
} awe_url_filtering_mode;
typedef enum _awe_webkey_type
{
AWE_WKT_KEYDOWN,
AWE_WKT_KEYUP,
AWE_WKT_CHAR
} awe_webkey_type;
typedef enum _awe_webkey_modifiers
{
AWE_WKM_SHIFT_KEY = 0x01,
AWE_WKM_CONTROL_KEY = 0x02,
AWE_WKM_ALT_KEY = 0x04,
AWE_WKM_META_KEY = 0x08,
AWE_WKM_IS_KEYPAD = 0x10,
AWE_WKM_IS_AUTOREPEAT = 0x20,
} awe_webkey_modifiers;
typedef enum _awe_cursor_type
{
AWE_CUR_POINTER,
AWE_CUR_CROSS,
AWE_CUR_HAND,
AWE_CUR_IBEAM,
AWE_CUR_WAIT,
AWE_CUR_HELP,
AWE_CUR_EAST_RESIZE,
AWE_CUR_NORTH_RESIZE,
AWE_CUR_NORTHEAST_RESIZE,
AWE_CUR_NORTHWEST_RESIZE,
AWE_CUR_SOUTH_RESIZE,
AWE_CUR_SOUTHEAST_RESIZE,
AWE_CUR_SOUTHWEST_RESIZE,
AWE_CUR_WEST_RESIZE,
AWE_CUR_NORTHSOUTH_RESIZE,
AWE_CUR_EASTWEST_RESIZE,
AWE_CUR_NORTHEAST_SOUTHWEST_RESIZE,
AWE_CUR_NORTHWEST_SOUTHEAST_RESIZE,
AWE_CUR_COLUMN_RESIZE,
AWE_CUR_ROW_RESIZE,
AWE_CUR_MIDDLE_PANNING,
AWE_CUR_EAST_PANNING,
AWE_CUR_NORTH_PANNING,
AWE_CUR_NORTHEAST_PANNING,
AWE_CUR_NORTHWEST_PANNING,
AWE_CUR_SOUTH_PANNING,
AWE_CUR_SOUTHEAST_PANNING,
AWE_CUR_SOUTHWEST_PANNING,
AWE_CUR_WEST_PANNING,
AWE_CUR_MOVE,
AWE_CUR_VERTICAL_TEXT,
AWE_CUR_CELL,
AWE_CUR_CONTEXT_MENU,
AWE_CUR_ALIAS,
AWE_CUR_PROGRESS,
AWE_CUR_NO_DROP,
AWE_CUR_COPY,
AWE_CUR_NONE,
AWE_CUR_NOT_ALLOWED,
AWE_CUR_ZOOM_IN,
AWE_CUR_ZOOM_OUT,
AWE_CUR_CUSTOM
} awe_cursor_type;
typedef enum _awe_ime_state
{
AWE_IME_DISABLE = 0,
AWE_IME_MOVE_WINDOW = 1,
AWE_IME_COMPLETE_COMPOSITION = 2
} awe_ime_state;
typedef enum _awe_media_type
{
AWE_MEDIA_TYPE_NONE,
AWE_MEDIA_TYPE_IMAGE,
AWE_MEDIA_TYPE_VIDEO,
AWE_MEDIA_TYPE_AUDIO
} awe_media_type;
typedef enum _awe_media_state
{
AWE_MEDIA_STATE_NONE = 0x0,
AWE_MEDIA_STATE_ERROR = 0x1,
AWE_MEDIA_STATE_PAUSED = 0x2,
AWE_MEDIA_STATE_MUTED = 0x4,
AWE_MEDIA_STATE_LOOP = 0x8,
AWE_MEDIA_STATE_CAN_SAVE = 0x10,
AWE_MEDIA_STATE_HAS_AUDIO = 0x20
};
enum _awe_can_edit_flags
{
AWE_CAN_EDIT_NOTHING = 0x0,
AWE_CAN_UNDO = 0x1,
AWE_CAN_REDO = 0x2,
AWE_CAN_CUT = 0x4,
AWE_CAN_COPY = 0x8,
AWE_CAN_PASTE = 0x10,
AWE_CAN_DELETE = 0x20,
AWE_CAN_SELECT_ALL = 0x40
};
enum _awe_dialog_flags
{
AWE_DIALOG_HAS_OK_BUTTON = 0x1,
AWE_DIALOG_HAS_CANCEL_BUTTON = 0x2,
AWE_DIALOG_HAS_PROMPT_FIELD = 0x4,
AWE_DIALOG_HAS_MESSAGE = 0x8
};
typedef struct _awe_webkeyboardevent
{
awe_webkey_type type;
int modifiers;
int virtual_key_code;
int native_key_code;
wchar16 text[4];
wchar16 unmodified_text[4];
bool is_system_key;
} awe_webkeyboardevent;
typedef struct _awe_rect
{
int x, y, width, height;
} awe_rect;
bool awe_is_child_process(int argc, char** argv);
int awe_child_process_main(int argc, char** argv);
const awe_string* awe_string_empty();
awe_string* awe_string_create_from_ascii(const char* str,
size_t len);
awe_string* awe_string_create_from_wide(const wchar_t* str,
size_t len);
awe_string* awe_string_create_from_utf8(const char* str,
size_t len);
awe_string* awe_string_create_from_utf16(const wchar16* str,
size_t len);
void awe_string_destroy(awe_string* str);
size_t awe_string_get_length(const awe_string* str);
const wchar16* awe_string_get_utf16(const awe_string* str);
int awe_string_to_wide(const awe_string* str,
wchar_t* dest,
size_t len);
int awe_string_to_utf8(const awe_string* str,
char* dest,
size_t len);
void awe_webcore_initialize(bool enable_plugins,
bool enable_javascript,
bool enable_databases,
const awe_string* package_path,
const awe_string* locale_path,
const awe_string* user_data_path,
const awe_string* plugin_path,
const awe_string* log_path,
awe_loglevel log_level,
bool force_single_process,
const awe_string* child_process_path,
bool enable_auto_detect_encoding,
const awe_string* accept_language_override,
const awe_string* default_charset_override,
const awe_string* user_agent_override,
const awe_string* proxy_server,
const awe_string* proxy_config_script,
const awe_string* auth_server_whitelist,
bool save_cache_and_cookies,
int max_cache_size,
bool disable_same_origin_policy,
bool disable_win_message_pump,
const awe_string* custom_css);
void awe_webcore_initialize_default();
void awe_webcore_shutdown();
void awe_webcore_set_base_directory(const awe_string* base_dir_path);
awe_webview* awe_webcore_create_webview(int width, int height,
bool view_source);
void awe_webcore_set_custom_response_page(int status_code,
const awe_string* file_path);
void awe_webcore_update();
const awe_string* awe_webcore_get_base_directory();
bool awe_webcore_are_plugins_enabled();
void awe_webcore_clear_cache();
void awe_webcore_clear_cookies();
void awe_webcore_set_cookie(const awe_string* url,
const awe_string* cookie_string,
bool is_http_only,
bool force_session_cookie);
const awe_string* awe_webcore_get_cookies(const awe_string* url,
bool exclude_http_only);
void awe_webcore_delete_cookie(const awe_string* url,
const awe_string* cookie_name);
void awe_webcore_set_suppress_printer_dialog(bool suppress);
awe_history_query_result* awe_webcore_query_history(const awe_string* full_text_query,
int num_days_ago, int max_count);
void awe_webview_destroy(awe_webview* webview);
void awe_webview_load_url(awe_webview* webview,
const awe_string* url,
const awe_string* frame_name,
const awe_string* username,
const awe_string* password);
void awe_webview_load_html(awe_webview* webview,
const awe_string* html,
const awe_string* frame_name);
void awe_webview_load_file(awe_webview* webview,
const awe_string* file,
const awe_string* frame_name);
awe_string* awe_webview_get_url(awe_webview* webview);
void awe_webview_go_to_history_offset(awe_webview* webview,
int offset);
int awe_webview_get_history_back_count(awe_webview* webview);
int awe_webview_get_history_forward_count(awe_webview* webview);
void awe_webview_stop(awe_webview* webview);
void awe_webview_reload(awe_webview* webview);
void awe_webview_execute_javascript(awe_webview* webview,
const awe_string* javascript,
const awe_string* frame_name);
awe_jsvalue* awe_webview_execute_javascript_with_result(
awe_webview* webview,
const awe_string* javascript,
const awe_string* frame_name,
int timeout_ms);
void awe_webview_call_javascript_function(awe_webview* webview,
const awe_string* object,
const awe_string* function,
const awe_jsarray* arguments,
const awe_string* frame_name);
void awe_webview_create_object(awe_webview* webview,
const awe_string* object_name);
void awe_webview_destroy_object(awe_webview* webview,
const awe_string* object_name);
void awe_webview_set_object_property(awe_webview* webview,
const awe_string* object_name,
const awe_string* property_name,
const awe_jsvalue* value);
void awe_webview_set_object_callback(awe_webview* webview,
const awe_string* object_name,
const awe_string* callback_name);
bool awe_webview_is_loading_page(awe_webview* webview);
bool awe_webview_is_dirty(awe_webview* webview);
awe_rect awe_webview_get_dirty_bounds(awe_webview* webview);
const awe_renderbuffer* awe_webview_render(awe_webview* webview);
void awe_webview_pause_rendering(awe_webview* webview);
void awe_webview_resume_rendering(awe_webview* webview);
void awe_webview_inject_mouse_move(awe_webview* webview,
int x,
int y);
void awe_webview_inject_mouse_down(awe_webview* webview,
awe_mousebutton button);
void awe_webview_inject_mouse_up(awe_webview* webview,
awe_mousebutton button);
void awe_webview_inject_mouse_wheel(awe_webview* webview,
int scroll_amount_vert,
int scroll_amount_horz);
void awe_webview_inject_keyboard_event(awe_webview* webview,
awe_webkeyboardevent key_event);
void awe_webview_cut(awe_webview* webview);
void awe_webview_copy(awe_webview* webview);
void awe_webview_paste(awe_webview* webview);
void awe_webview_select_all(awe_webview* webview);
void awe_webview_copy_image_at(awe_webview* webview,
int x,
int y);
void awe_webview_set_zoom(awe_webview* webview,
int zoom_percent);
void awe_webview_reset_zoom(awe_webview* webview);
int awe_webview_get_zoom(awe_webview* webview);
int awe_webview_get_zoom_for_host(awe_webview* webview,
const awe_string* host);
bool awe_webview_resize(awe_webview* webview,
int width,
int height,
bool wait_for_repaint,
int repaint_timeout_ms);
bool awe_webview_is_resizing(awe_webview* webview);
void awe_webview_unfocus(awe_webview* webview);
void awe_webview_focus(awe_webview* webview);
void awe_webview_set_transparent(awe_webview* webview,
bool is_transparent);
bool awe_webview_is_transparent(awe_webview* webview);
void awe_webview_set_url_filtering_mode(awe_webview* webview,
awe_url_filtering_mode mode);
void awe_webview_add_url_filter(awe_webview* webview,
const awe_string* filter);
void awe_webview_clear_all_url_filters(awe_webview* webview);
void awe_webview_set_header_definition(awe_webview* webview,
const awe_string* name,
size_t num_fields,
const awe_string** field_names,
const awe_string** field_values);
void awe_webview_add_header_rewrite_rule(awe_webview* webview,
const awe_string* rule,
const awe_string* name);
void awe_webview_remove_header_rewrite_rule(awe_webview* webview,
const awe_string* rule);
void awe_webview_remove_header_rewrite_rules_by_definition_name(
awe_webview* webview,
const awe_string* name);
void awe_webview_choose_file(awe_webview* webview,
const awe_string* file_path);
void awe_webview_print(awe_webview* webview);
void awe_webview_request_scroll_data(awe_webview* webview,
const awe_string* frame_name);
void awe_webview_find(awe_webview* webview,
int request_id,
const awe_string* search_string,
bool forward,
bool case_sensitive,
bool find_next);
void awe_webview_stop_find(awe_webview* webview,
bool clear_selection);
void awe_webview_translate_page(awe_webview* webview,
const awe_string* source_language,
const awe_string* target_language);
void awe_webview_activate_ime(awe_webview* webview,
bool activate);
void awe_webview_set_ime_composition(awe_webview* webview,
const awe_string* input_string,
int cursor_pos,
int target_start,
int target_end);
void awe_webview_confirm_ime_composition(awe_webview* webview,
const awe_string* input_string);
void awe_webview_cancel_ime_composition(awe_webview* webview);
void awe_webview_login(awe_webview* webview,
int request_id,
const awe_string* username,
const awe_string* password);
void awe_webview_cancel_login(awe_webview* webview,
int request_id);
void awe_webview_close_javascript_dialog(awe_webview* webview,
int request_id,
bool was_cancelled,
const awe_string* prompt_text);
void awe_webview_set_callback_begin_navigation(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* url,
const awe_string* frame_name));
void awe_webview_set_callback_begin_loading(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* url,
const awe_string* frame_name,
int status_code,
const awe_string* mime_type));
void awe_webview_set_callback_finish_loading(
awe_webview* webview,
void (*callback)(awe_webview* caller));
void awe_webview_set_callback_js_callback(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* object_name,
const awe_string* callback_name,
const awe_jsarray* arguments));
void awe_webview_set_callback_receive_title(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* title,
const awe_string* frame_name));
void awe_webview_set_callback_change_tooltip(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* tooltip));
void awe_webview_set_callback_change_cursor(
awe_webview* webview,
void (*callback)(awe_webview* caller,
awe_cursor_type cursor));
void awe_webview_set_callback_change_keyboard_focus(
awe_webview* webview,
void (*callback)(awe_webview* caller,
bool is_focused));
void awe_webview_set_callback_change_target_url(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* url));
void awe_webview_set_callback_open_external_link(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* url,
const awe_string* source));
void awe_webview_set_callback_request_download(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* download));
void awe_webview_set_callback_web_view_crashed(
awe_webview* webview,
void (*callback)(awe_webview* caller));
void awe_webview_set_callback_plugin_crashed(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* plugin_name));
void awe_webview_set_callback_request_move(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int x,
int y));
void awe_webview_set_callback_get_page_contents(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* url,
const awe_string* contents));
void awe_webview_set_callback_dom_ready(
awe_webview* webview,
void (*callback)(awe_webview* caller));
void awe_webview_set_callback_request_file_chooser(
awe_webview* webview,
void (*callback)(awe_webview* caller,
bool select_multiple_files,
const awe_string* title,
const awe_string* default_path));
void awe_webview_set_callback_get_scroll_data(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int contentWidth,
int contentHeight,
int preferredWidth,
int scrollX,
int scrollY));
void awe_webview_set_callback_js_console_message(
awe_webview* webview,
void (*callback)(awe_webview* caller,
const awe_string* message,
int line_number,
const awe_string* source));
void awe_webview_set_callback_get_find_results(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int request_id,
int num_matches,
awe_rect selection,
int cur_match,
bool finalUpdate));
void awe_webview_set_callback_update_ime(
awe_webview* webview,
void (*callback)(awe_webview* caller,
awe_ime_state state,
awe_rect caret_rect));
void awe_webview_set_callback_show_context_menu(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int mouse_x,
int mouse_y,
awe_media_type type,
int media_state,
const awe_string* link_url,
const awe_string* src_url,
const awe_string* page_url,
const awe_string* frame_url,
const awe_string* selection_text,
bool is_editable,
int edit_flags));
void awe_webview_set_callback_request_login(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int request_id,
const awe_string* request_url,
bool is_proxy,
const awe_string* host_and_port,
const awe_string* scheme,
const awe_string* realm));
void awe_webview_set_callback_change_history(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int back_count,
int forward_count));
void awe_webview_set_callback_finish_resize(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int width,
int height));
void awe_webview_set_callback_show_javascript_dialog(
awe_webview* webview,
void (*callback)(awe_webview* caller,
int request_id,
int dialog_flags,
const awe_string* message,
const awe_string* default_prompt,
const awe_string* frame_url));
typedef enum _awe_jsvalue_type
{
JSVALUE_TYPE_NULL,
JSVALUE_TYPE_BOOLEAN,
JSVALUE_TYPE_INTEGER,
JSVALUE_TYPE_DOUBLE,
JSVALUE_TYPE_STRING,
JSVALUE_TYPE_OBJECT,
JSVALUE_TYPE_ARRAY
} awe_jsvalue_type;
awe_jsvalue* awe_jsvalue_create_null_value();
awe_jsvalue* awe_jsvalue_create_bool_value(bool value);
awe_jsvalue* awe_jsvalue_create_integer_value(int value);
awe_jsvalue* awe_jsvalue_create_double_value(double value);
awe_jsvalue* awe_jsvalue_create_string_value(const awe_string* value);
awe_jsvalue* awe_jsvalue_create_object_value(const awe_jsobject* value);
awe_jsvalue* awe_jsvalue_create_array_value(const awe_jsarray* value);
void awe_jsvalue_destroy(awe_jsvalue* jsvalue);
awe_jsvalue_type awe_jsvalue_get_type(const awe_jsvalue* jsvalue);
awe_string* awe_jsvalue_to_string(const awe_jsvalue* jsvalue);
int awe_jsvalue_to_integer(const awe_jsvalue* jsvalue);
double awe_jsvalue_to_double(const awe_jsvalue* jsvalue);
bool awe_jsvalue_to_boolean(const awe_jsvalue* jsvalue);
const awe_jsarray* awe_jsvalue_get_array(const awe_jsvalue* jsvalue);
const awe_jsobject* awe_jsvalue_get_object(const awe_jsvalue* jsvalue);
awe_jsarray* awe_jsarray_create(const awe_jsvalue** jsvalue_array,
size_t length);
void awe_jsarray_destroy(awe_jsarray* jsarray);
size_t awe_jsarray_get_size(const awe_jsarray* jsarray);
const awe_jsvalue* awe_jsarray_get_element(const awe_jsarray* jsarray,
size_t index);
awe_jsobject* awe_jsobject_create();
void awe_jsobject_destroy(awe_jsobject* jsobject);
bool awe_jsobject_has_property(const awe_jsobject* jsobject,
const awe_string* property_name);
const awe_jsvalue* awe_jsobject_get_property(const awe_jsobject* jsobject,
const awe_string* property_name);
void awe_jsobject_set_property(awe_jsobject* jsobject,
const awe_string* property_name,
const awe_jsvalue* value);
size_t awe_jsobject_get_size(awe_jsobject* jsobject);
awe_jsarray* awe_jsobject_get_keys(awe_jsobject* jsobject);
int awe_renderbuffer_get_width(const awe_renderbuffer* renderbuffer);
int awe_renderbuffer_get_height(const awe_renderbuffer* renderbuffer);
int awe_renderbuffer_get_rowspan(const awe_renderbuffer* renderbuffer);
const unsigned char* awe_renderbuffer_get_buffer(
const awe_renderbuffer* renderbuffer);
void awe_renderbuffer_copy_to(const awe_renderbuffer* renderbuffer,
unsigned char* dest_buffer,
int dest_rowspan,
int dest_depth,
bool convert_to_rgba,
bool flip_y);
void awe_renderbuffer_copy_to_float(const awe_renderbuffer* renderbuffer,
float* dest_buffer);
bool awe_renderbuffer_save_to_png(const awe_renderbuffer* renderbuffer,
const awe_string* file_path,
bool preserve_transparency);
bool awe_renderbuffer_save_to_jpeg(const awe_renderbuffer* renderbuffer,
const awe_string* file_path,
int quality);
unsigned char awe_renderbuffer_get_alpha_at_point(const awe_renderbuffer* renderbuffer,
int x,
int y);
void awe_renderbuffer_flush_alpha(const awe_renderbuffer* renderbuffer);
void awe_webview_set_callback_resource_request(
awe_webview* webview,
awe_resource_response* (*callback)(
awe_webview* caller,
awe_resource_request* request));
void awe_webview_set_callback_resource_response(
awe_webview* webview,
void (*callback)(
awe_webview* caller,
const awe_string* url,
int status_code,
bool was_cached,
int64 request_time_ms,
int64 response_time_ms,
int64 expected_content_size,
const awe_string* mime_type));
awe_resource_response* awe_resource_response_create(
size_t num_bytes,
unsigned char* buffer,
const awe_string* mime_type);
awe_resource_response* awe_resource_response_create_from_file(
const awe_string* file_path);
void awe_resource_request_cancel(awe_resource_request* request);
awe_string* awe_resource_request_get_url(awe_resource_request* request);
awe_string* awe_resource_request_get_method(awe_resource_request* request);
void awe_resource_request_set_method(awe_resource_request* request,
const awe_string* method);
awe_string* awe_resource_request_get_referrer(awe_resource_request* request);
void awe_resource_request_set_referrer(awe_resource_request* request,
const awe_string* referrer);
awe_string* awe_resource_request_get_extra_headers(awe_resource_request* request);
void awe_resource_request_set_extra_headers(awe_resource_request* request,
const awe_string* headers);
void awe_resource_request_append_extra_header(awe_resource_request* request,
const awe_string* name,
const awe_string* value);
size_t awe_resource_request_get_num_upload_elements(awe_resource_request* request);
const awe_upload_element* awe_resource_request_get_upload_element(awe_resource_request* request,
size_t idx);
void awe_resource_request_clear_upload_elements(awe_resource_request* request);
void awe_resource_request_append_upload_file_path(awe_resource_request* request,
const awe_string* file_path);
void awe_resource_request_append_upload_bytes(awe_resource_request* request,
const awe_string* bytes);
bool awe_upload_element_is_file_path(const awe_upload_element* ele);
bool awe_upload_element_is_bytes(const awe_upload_element* ele);
awe_string* awe_upload_element_get_bytes(const awe_upload_element* ele);
awe_string* awe_upload_element_get_file_path(const awe_upload_element* ele);
void awe_history_query_result_destroy(awe_history_query_result* res);
size_t awe_history_query_result_get_size(awe_history_query_result* res);
awe_history_entry* awe_history_query_result_get_entry_at_index(awe_history_query_result* res,
size_t idx);
void awe_history_entry_destroy(awe_history_entry* entry);
awe_string* awe_history_entry_get_url(awe_history_entry* entry);
awe_string* awe_history_entry_get_title(awe_history_entry* entry);
double awe_history_entry_get_visit_time(awe_history_entry* entry);
int awe_history_entry_get_visit_count(awe_history_entry* entry);

""")

awe_webview_unfocus = guard(lookup('awe_webview_unfocus'))
awe_webview_reload = guard(lookup('awe_webview_reload'))
AWE_CUR_SOUTHEAST_RESIZE = 11
awe_renderbuffer_get_width = guard(lookup('awe_renderbuffer_get_width'))
awe_webview_execute_javascript_with_result = guard(lookup('awe_webview_execute_javascript_with_result'))
AWE_DIALOG_HAS_MESSAGE = 8
AWE_CAN_DELETE = 32
awe_jsobject_get_property = guard(lookup('awe_jsobject_get_property'))
AWE_CAN_UNDO = 1
awe_jsvalue_create_string_value = guard(lookup('awe_jsvalue_create_string_value'))
AWE_CUR_NORTH_PANNING = 22
awe_jsvalue_create_null_value = guard(lookup('awe_jsvalue_create_null_value'))
awe_webcore_get_base_directory = guard(lookup('awe_webcore_get_base_directory'))
awe_webview_call_javascript_function = guard(lookup('awe_webview_call_javascript_function'))
awe_resource_request_set_method = guard(lookup('awe_resource_request_set_method'))
AWE_CUR_ZOOM_OUT = 40
JSVALUE_TYPE_STRING = 4
awe_webview_add_header_rewrite_rule = guard(lookup('awe_webview_add_header_rewrite_rule'))
awe_webview_load_html = guard(lookup('awe_webview_load_html'))
AWE_CUR_NORTHWEST_RESIZE = 9
awe_jsvalue_get_type = guard(lookup('awe_jsvalue_get_type'))
awe_webview_confirm_ime_composition = guard(lookup('awe_webview_confirm_ime_composition'))
awe_webcore_set_suppress_printer_dialog = guard(lookup('awe_webcore_set_suppress_printer_dialog'))
awe_webview_find = guard(lookup('awe_webview_find'))
awe_webview_inject_mouse_down = guard(lookup('awe_webview_inject_mouse_down'))
awe_webcore_delete_cookie = guard(lookup('awe_webcore_delete_cookie'))
AWE_CAN_COPY = 8
awe_upload_element_get_bytes = guard(lookup('awe_upload_element_get_bytes'))
AWE_WKT_CHAR = 2
awe_jsarray_get_element = guard(lookup('awe_jsarray_get_element'))
JSVALUE_TYPE_NULL = 0
AWE_CUR_NORTHWEST_SOUTHEAST_RESIZE = 17
awe_string_destroy = guard(lookup('awe_string_destroy'))
AWE_CUR_HELP = 5
awe_jsvalue_to_integer = guard(lookup('awe_jsvalue_to_integer'))
awe_webcore_set_cookie = guard(lookup('awe_webcore_set_cookie'))
AWE_WKT_KEYDOWN = 0
awe_webview_set_callback_request_file_chooser = guard(lookup('awe_webview_set_callback_request_file_chooser'))
AWE_IME_COMPLETE_COMPOSITION = 2
awe_webview_set_header_definition = guard(lookup('awe_webview_set_header_definition'))
awe_resource_request_get_num_upload_elements = guard(lookup('awe_resource_request_get_num_upload_elements'))
awe_history_query_result_get_size = guard(lookup('awe_history_query_result_get_size'))
AWE_CUR_CELL = 31
awe_webview_close_javascript_dialog = guard(lookup('awe_webview_close_javascript_dialog'))
AWE_CUR_WEST_PANNING = 28
AWE_MEDIA_STATE_LOOP = 8
awe_webcore_set_base_directory = guard(lookup('awe_webcore_set_base_directory'))
awe_history_entry_get_title = guard(lookup('awe_history_entry_get_title'))
awe_webview_activate_ime = guard(lookup('awe_webview_activate_ime'))
AWE_LL_NORMAL = 1
JSVALUE_TYPE_INTEGER = 2
AWE_DIALOG_HAS_CANCEL_BUTTON = 2
AWE_CUR_WEST_RESIZE = 13
AWE_MEDIA_STATE_CAN_SAVE = 16
awe_webview_print = guard(lookup('awe_webview_print'))
AWE_IME_DISABLE = 0
awe_webview_login = guard(lookup('awe_webview_login'))
AWE_UFM_BLACKLIST = 1
awe_jsarray_destroy = guard(lookup('awe_jsarray_destroy'))
AWE_CUR_CONTEXT_MENU = 32
AWE_DIALOG_HAS_PROMPT_FIELD = 4
awe_jsarray_get_size = guard(lookup('awe_jsarray_get_size'))
AWE_MEDIA_TYPE_AUDIO = 3
AWE_MEDIA_TYPE_VIDEO = 2
awe_webview_set_callback_get_find_results = guard(lookup('awe_webview_set_callback_get_find_results'))
AWE_WKM_IS_KEYPAD = 16
awe_webcore_clear_cache = guard(lookup('awe_webcore_clear_cache'))
awe_webview_choose_file = guard(lookup('awe_webview_choose_file'))
AWE_LL_VERBOSE = 2
AWE_LL_NONE = 0
JSVALUE_TYPE_OBJECT = 5
awe_webview_get_zoom = guard(lookup('awe_webview_get_zoom'))
AWE_UFM_NONE = 0
AWE_MEDIA_STATE_HAS_AUDIO = 32
awe_resource_request_append_extra_header = guard(lookup('awe_resource_request_append_extra_header'))
awe_webview_set_callback_update_ime = guard(lookup('awe_webview_set_callback_update_ime'))
AWE_WKT_KEYUP = 1
JSVALUE_TYPE_BOOLEAN = 1
awe_renderbuffer_get_buffer = guard(lookup('awe_renderbuffer_get_buffer'))
awe_history_entry_get_visit_time = guard(lookup('awe_history_entry_get_visit_time'))
AWE_WKM_META_KEY = 8
awe_resource_request_set_referrer = guard(lookup('awe_resource_request_set_referrer'))
AWE_CUR_COLUMN_RESIZE = 18
AWE_CUR_SOUTHWEST_RESIZE = 12
AWE_CUR_EAST_RESIZE = 6
awe_webview_paste = guard(lookup('awe_webview_paste'))
awe_webview_set_callback_resource_request = guard(lookup('awe_webview_set_callback_resource_request'))
awe_webview_request_scroll_data = guard(lookup('awe_webview_request_scroll_data'))
AWE_CUR_ZOOM_IN = 39
awe_jsobject_destroy = guard(lookup('awe_jsobject_destroy'))
AWE_MB_RIGHT = 2
AWE_CUR_POINTER = 0
awe_jsobject_create = guard(lookup('awe_jsobject_create'))
AWE_CUR_MOVE = 29
AWE_MEDIA_STATE_ERROR = 1
awe_string_create_from_utf16 = guard(lookup('awe_string_create_from_utf16'))
awe_webview_is_transparent = guard(lookup('awe_webview_is_transparent'))
AWE_CUR_NORTHEAST_PANNING = 23
awe_webview_set_callback_resource_response = guard(lookup('awe_webview_set_callback_resource_response'))
AWE_CUR_NORTHEAST_RESIZE = 8
awe_webview_load_url = guard(lookup('awe_webview_load_url'))
awe_webview_set_callback_request_login = guard(lookup('awe_webview_set_callback_request_login'))
AWE_CUR_SOUTHWEST_PANNING = 27
AWE_CUR_NO_DROP = 35
awe_jsarray_create = guard(lookup('awe_jsarray_create'))
JSVALUE_TYPE_DOUBLE = 3
awe_webview_set_callback_get_page_contents = guard(lookup('awe_webview_set_callback_get_page_contents'))
awe_webview_set_callback_begin_loading = guard(lookup('awe_webview_set_callback_begin_loading'))
awe_webview_set_callback_show_javascript_dialog = guard(lookup('awe_webview_set_callback_show_javascript_dialog'))
awe_renderbuffer_get_alpha_at_point = guard(lookup('awe_renderbuffer_get_alpha_at_point'))
awe_string_to_utf8 = guard(lookup('awe_string_to_utf8'))
awe_webview_set_zoom = guard(lookup('awe_webview_set_zoom'))
AWE_CAN_CUT = 4
awe_webview_set_object_callback = guard(lookup('awe_webview_set_object_callback'))
AWE_WKM_ALT_KEY = 4
awe_resource_response_create = guard(lookup('awe_resource_response_create'))
awe_jsvalue_get_array = guard(lookup('awe_jsvalue_get_array'))
awe_webview_inject_keyboard_event = guard(lookup('awe_webview_inject_keyboard_event'))
awe_webview_render = guard(lookup('awe_webview_render'))
awe_history_entry_get_url = guard(lookup('awe_history_entry_get_url'))
AWE_CUR_SOUTHEAST_PANNING = 26
awe_webview_inject_mouse_wheel = guard(lookup('awe_webview_inject_mouse_wheel'))
AWE_CUR_COPY = 36
JSVALUE_TYPE_ARRAY = 6
awe_resource_request_get_upload_element = guard(lookup('awe_resource_request_get_upload_element'))
awe_webview_destroy_object = guard(lookup('awe_webview_destroy_object'))
awe_string_empty = guard(lookup('awe_string_empty'))
awe_webview_get_history_back_count = guard(lookup('awe_webview_get_history_back_count'))
awe_webview_create_object = guard(lookup('awe_webview_create_object'))
AWE_DIALOG_HAS_OK_BUTTON = 1
AWE_CUR_CROSS = 1
AWE_CUR_PROGRESS = 34
awe_webview_reset_zoom = guard(lookup('awe_webview_reset_zoom'))
AWE_CUR_SOUTH_PANNING = 25
awe_webview_set_callback_begin_navigation = guard(lookup('awe_webview_set_callback_begin_navigation'))
awe_webview_cut = guard(lookup('awe_webview_cut'))
AWE_MEDIA_TYPE_IMAGE = 1
awe_webview_is_dirty = guard(lookup('awe_webview_is_dirty'))
AWE_CUR_VERTICAL_TEXT = 30
awe_webview_get_dirty_bounds = guard(lookup('awe_webview_get_dirty_bounds'))
AWE_MB_LEFT = 0
awe_jsobject_has_property = guard(lookup('awe_jsobject_has_property'))
awe_renderbuffer_flush_alpha = guard(lookup('awe_renderbuffer_flush_alpha'))
AWE_CUR_EAST_PANNING = 21
awe_webcore_query_history = guard(lookup('awe_webcore_query_history'))
awe_upload_element_is_file_path = guard(lookup('awe_upload_element_is_file_path'))
awe_webcore_clear_cookies = guard(lookup('awe_webcore_clear_cookies'))
awe_webview_go_to_history_offset = guard(lookup('awe_webview_go_to_history_offset'))
awe_resource_request_cancel = guard(lookup('awe_resource_request_cancel'))
awe_webview_inject_mouse_move = guard(lookup('awe_webview_inject_mouse_move'))
awe_webview_resume_rendering = guard(lookup('awe_webview_resume_rendering'))
awe_renderbuffer_get_rowspan = guard(lookup('awe_renderbuffer_get_rowspan'))
awe_renderbuffer_save_to_jpeg = guard(lookup('awe_renderbuffer_save_to_jpeg'))
awe_webview_focus = guard(lookup('awe_webview_focus'))
awe_webview_set_callback_change_history = guard(lookup('awe_webview_set_callback_change_history'))
AWE_MB_MIDDLE = 1
awe_webview_set_object_property = guard(lookup('awe_webview_set_object_property'))
awe_webview_inject_mouse_up = guard(lookup('awe_webview_inject_mouse_up'))
awe_jsvalue_to_boolean = guard(lookup('awe_jsvalue_to_boolean'))
awe_resource_request_get_referrer = guard(lookup('awe_resource_request_get_referrer'))
awe_renderbuffer_copy_to = guard(lookup('awe_renderbuffer_copy_to'))
awe_webcore_initialize_default = guard(lookup('awe_webcore_initialize_default'))
awe_webview_load_file = guard(lookup('awe_webview_load_file'))
awe_renderbuffer_save_to_png = guard(lookup('awe_renderbuffer_save_to_png'))
AWE_CUR_EASTWEST_RESIZE = 15
awe_webview_get_zoom_for_host = guard(lookup('awe_webview_get_zoom_for_host'))
awe_upload_element_is_bytes = guard(lookup('awe_upload_element_is_bytes'))
AWE_MEDIA_STATE_MUTED = 4
AWE_WKM_SHIFT_KEY = 1
awe_resource_request_get_url = guard(lookup('awe_resource_request_get_url'))
AWE_CUR_ROW_RESIZE = 19
AWE_CUR_HAND = 2
awe_resource_request_append_upload_bytes = guard(lookup('awe_resource_request_append_upload_bytes'))
awe_webview_set_ime_composition = guard(lookup('awe_webview_set_ime_composition'))
AWE_CAN_SELECT_ALL = 64
awe_webview_get_history_forward_count = guard(lookup('awe_webview_get_history_forward_count'))
awe_webview_set_url_filtering_mode = guard(lookup('awe_webview_set_url_filtering_mode'))
awe_resource_request_get_extra_headers = guard(lookup('awe_resource_request_get_extra_headers'))
awe_renderbuffer_copy_to_float = guard(lookup('awe_renderbuffer_copy_to_float'))
awe_webview_destroy = guard(lookup('awe_webview_destroy'))
awe_resource_response_create_from_file = guard(lookup('awe_resource_response_create_from_file'))
awe_webcore_are_plugins_enabled = guard(lookup('awe_webcore_are_plugins_enabled'))
awe_webview_stop_find = guard(lookup('awe_webview_stop_find'))
awe_webview_set_callback_dom_ready = guard(lookup('awe_webview_set_callback_dom_ready'))
awe_webcore_create_webview = guard(lookup('awe_webcore_create_webview'))
awe_webview_set_callback_finish_loading = guard(lookup('awe_webview_set_callback_finish_loading'))
awe_resource_request_set_extra_headers = guard(lookup('awe_resource_request_set_extra_headers'))
awe_resource_request_append_upload_file_path = guard(lookup('awe_resource_request_append_upload_file_path'))
awe_webview_set_callback_change_keyboard_focus = guard(lookup('awe_webview_set_callback_change_keyboard_focus'))
awe_jsvalue_to_string = guard(lookup('awe_jsvalue_to_string'))
awe_history_query_result_get_entry_at_index = guard(lookup('awe_history_query_result_get_entry_at_index'))
awe_renderbuffer_get_height = guard(lookup('awe_renderbuffer_get_height'))
awe_jsvalue_create_array_value = guard(lookup('awe_jsvalue_create_array_value'))
AWE_CUR_ALIAS = 33
awe_string_get_utf16 = guard(lookup('awe_string_get_utf16'))
AWE_CUR_NORTHEAST_SOUTHWEST_RESIZE = 16
awe_webview_set_callback_show_context_menu = guard(lookup('awe_webview_set_callback_show_context_menu'))
awe_jsvalue_create_bool_value = guard(lookup('awe_jsvalue_create_bool_value'))
AWE_CUR_NORTHWEST_PANNING = 24
awe_is_child_process = guard(lookup('awe_is_child_process'))
awe_resource_request_clear_upload_elements = guard(lookup('awe_resource_request_clear_upload_elements'))
AWE_CAN_EDIT_NOTHING = 0
awe_webview_set_callback_js_console_message = guard(lookup('awe_webview_set_callback_js_console_message'))
AWE_CUR_NOT_ALLOWED = 38
awe_webview_remove_header_rewrite_rules_by_definition_name = guard(lookup('awe_webview_remove_header_rewrite_rules_by_definition_name'))
AWE_CUR_NORTH_RESIZE = 7
awe_child_process_main = guard(lookup('awe_child_process_main'))
awe_webview_copy = guard(lookup('awe_webview_copy'))
awe_webview_stop = guard(lookup('awe_webview_stop'))
awe_webview_add_url_filter = guard(lookup('awe_webview_add_url_filter'))
awe_webview_get_url = guard(lookup('awe_webview_get_url'))
awe_string_create_from_ascii = guard(lookup('awe_string_create_from_ascii'))
awe_upload_element_get_file_path = guard(lookup('awe_upload_element_get_file_path'))
awe_jsvalue_get_object = guard(lookup('awe_jsvalue_get_object'))
awe_webview_is_resizing = guard(lookup('awe_webview_is_resizing'))
awe_jsobject_get_size = guard(lookup('awe_jsobject_get_size'))
awe_jsobject_get_keys = guard(lookup('awe_jsobject_get_keys'))
awe_string_create_from_utf8 = guard(lookup('awe_string_create_from_utf8'))
awe_webview_execute_javascript = guard(lookup('awe_webview_execute_javascript'))
awe_webview_set_callback_get_scroll_data = guard(lookup('awe_webview_set_callback_get_scroll_data'))
AWE_CUR_IBEAM = 3
AWE_IME_MOVE_WINDOW = 1
awe_webview_set_callback_receive_title = guard(lookup('awe_webview_set_callback_receive_title'))
awe_webview_translate_page = guard(lookup('awe_webview_translate_page'))
awe_webview_set_transparent = guard(lookup('awe_webview_set_transparent'))
AWE_MEDIA_STATE_NONE = 0
AWE_CAN_REDO = 2
awe_jsvalue_create_object_value = guard(lookup('awe_jsvalue_create_object_value'))
AWE_CAN_PASTE = 16
awe_webview_resize = guard(lookup('awe_webview_resize'))
awe_webview_is_loading_page = guard(lookup('awe_webview_is_loading_page'))
AWE_CUR_NORTHSOUTH_RESIZE = 14
awe_webview_set_callback_change_tooltip = guard(lookup('awe_webview_set_callback_change_tooltip'))
AWE_CUR_SOUTH_RESIZE = 10
awe_webview_clear_all_url_filters = guard(lookup('awe_webview_clear_all_url_filters'))
AWE_UFM_WHITELIST = 2
awe_jsvalue_create_integer_value = guard(lookup('awe_jsvalue_create_integer_value'))
awe_jsvalue_create_double_value = guard(lookup('awe_jsvalue_create_double_value'))
awe_webcore_initialize = guard(lookup('awe_webcore_initialize'))
awe_history_query_result_destroy = guard(lookup('awe_history_query_result_destroy'))
AWE_WKM_CONTROL_KEY = 2
awe_webview_set_callback_open_external_link = guard(lookup('awe_webview_set_callback_open_external_link'))
awe_string_get_length = guard(lookup('awe_string_get_length'))
awe_jsvalue_destroy = guard(lookup('awe_jsvalue_destroy'))
awe_webcore_get_cookies = guard(lookup('awe_webcore_get_cookies'))
AWE_MEDIA_TYPE_NONE = 0
awe_webview_pause_rendering = guard(lookup('awe_webview_pause_rendering'))
awe_webcore_set_custom_response_page = guard(lookup('awe_webcore_set_custom_response_page'))
awe_webview_cancel_ime_composition = guard(lookup('awe_webview_cancel_ime_composition'))
awe_webview_set_callback_js_callback = guard(lookup('awe_webview_set_callback_js_callback'))
awe_jsobject_set_property = guard(lookup('awe_jsobject_set_property'))
awe_webview_copy_image_at = guard(lookup('awe_webview_copy_image_at'))
awe_webview_remove_header_rewrite_rule = guard(lookup('awe_webview_remove_header_rewrite_rule'))
awe_resource_request_get_method = guard(lookup('awe_resource_request_get_method'))
awe_webview_set_callback_change_cursor = guard(lookup('awe_webview_set_callback_change_cursor'))
AWE_CUR_MIDDLE_PANNING = 20
awe_webview_select_all = guard(lookup('awe_webview_select_all'))
awe_history_entry_get_visit_count = guard(lookup('awe_history_entry_get_visit_count'))
awe_string_to_wide = guard(lookup('awe_string_to_wide'))
awe_webcore_update = guard(lookup('awe_webcore_update'))
awe_webview_set_callback_plugin_crashed = guard(lookup('awe_webview_set_callback_plugin_crashed'))
AWE_CUR_NONE = 37
AWE_WKM_IS_AUTOREPEAT = 32
awe_history_entry_destroy = guard(lookup('awe_history_entry_destroy'))
awe_webview_cancel_login = guard(lookup('awe_webview_cancel_login'))
awe_webview_set_callback_request_move = guard(lookup('awe_webview_set_callback_request_move'))
awe_webview_set_callback_request_download = guard(lookup('awe_webview_set_callback_request_download'))
awe_webview_set_callback_web_view_crashed = guard(lookup('awe_webview_set_callback_web_view_crashed'))
awe_jsvalue_to_double = guard(lookup('awe_jsvalue_to_double'))
AWE_MEDIA_STATE_PAUSED = 2
awe_string_create_from_wide = guard(lookup('awe_string_create_from_wide'))
awe_webview_set_callback_change_target_url = guard(lookup('awe_webview_set_callback_change_target_url'))
awe_webcore_shutdown = guard(lookup('awe_webcore_shutdown'))
awe_webview_set_callback_finish_resize = guard(lookup('awe_webview_set_callback_finish_resize'))
AWE_CUR_CUSTOM = 41
AWE_CUR_WAIT = 4


