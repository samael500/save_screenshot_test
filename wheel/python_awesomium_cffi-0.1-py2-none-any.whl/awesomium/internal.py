from __future__ import (print_function, division, absolute_import)

from cffi import FFI
import traceback
import sys
import os
import string
import stat
import logging

__all__ = [
    '_ffi',
    'load_lib',
    'lookup',
    'check_error',
    'guard',
]

_ffi = FFI()
_LIB = None

log = logging.getLogger('awesomium')

IS_DARWIN = sys.platform == 'darwin'
IS_WIN32 = sys.platform == 'win32'
IS_LINUX = sys.platform == 'linux2'

_THISDIR = os.path.abspath(os.path.dirname(__file__))
LIBDIR = os.path.join(_THISDIR, 'bin')

def add_ld_library_path():
    lib_path = os.environ.get('LD_LIBRARY_PATH','')
    if not lib_path:
        os.environ['LD_LIBRARY_PATH'] = LIBDIR
    else:
        os.environ['LD_LIBRARY_PATH'] = LIBDIR + os.pathsep + lib_path

def make_process_executable():
    # ensure process is executable
    if IS_DARWIN:
        binfile = os.path.join(LIBDIR, 'Awesomium.framework', 'Versions', 'A', 'AwesomiumProcess')
    else:
        binfile = os.path.join(LIBDIR, 'AwesomiumProcess')
    binmode = os.stat(binfile).st_mode
    execmode = stat.S_IXGRP | stat.S_IXOTH | stat.S_IXUSR
    if (binmode & execmode) != execmode:
        os.chmod(binfile, binmode | execmode)        

def load_lib(cdefs):
    global _LIB
    
    if IS_WIN32:
        srcpath = os.path.join(LIBDIR, 'Awesomium.dll')
        local_dls = [srcpath]
    elif IS_LINUX:
        add_ld_library_path()
        
        # ensure symlink
        srclinkpath = os.path.join(LIBDIR, 'libawesomium-1.6.5.so')
        dstlinkpath = os.path.join(LIBDIR, 'libawesomium-1.6.5.so.0') 
        if not os.path.isfile(dstlinkpath):
            os.symlink(os.path.split(srclinkpath)[1], dstlinkpath)
            
        make_process_executable()
            
        local_dls = [srclinkpath]        
    elif IS_DARWIN:
        add_ld_library_path()
        
        make_process_executable()
        
        local_dls = [os.path.join(LIBDIR, 'Awesomium.framework', 'Awesomium')]
    else:
        local_dls = []
        
    _ffi.cdef(cdefs)
    
    for dlpath in local_dls:
        try:
            _LIB = _ffi.dlopen(dlpath)
            return _LIB
        except OSError:
            traceback.print_exc()
        except:
            traceback.print_exc()
    log.error("unable to find Awesomium library")

def wrapstr(result):
    if result:
        return _ffi.string(result)
    return None

def wrap_retstr(func):
    def wrapper(*argv):
        return wrapstr(func(*argv))
    return wrapper

def lookup(name):
    if hasattr(_LIB, name):
        return getattr(_LIB, name)
    log.warn("Awesomium warning: function {} missing.".format(name))
    return None 
    
def check_error():
    pass

def guard(func):
    if not func:
        return None    
    name = repr(func)
    def newfunc(*args):
        result = func(*args)
        check_error()
        return result
    newfunc.func_name = name
    newfunc.__doc__ = func.__doc__
    return newfunc

def translate(txt):
    print(txt)
    for line in txt.split('\n'):
        line = line.strip()
        if not line.startswith('_OSMExport'):
            continue
        line = line.replace('_OSMExport', '')
        line = ' '.join([s for s in line.split() if s.strip()])
        items = []
        
        word = ''
        for c in line:
            if c in ' (),*':
                if word:
                    items, word = items + [word], ''
                if c != ' ':
                    items += [c]
            else:
                word += c
                
        def isword(s):
            st = string.ascii_letters + string.digits + '_'
            return len([c for c in s if c in st]) == len(s)
                
        head = []
        brackets = 0
        args = []
        arg = []
        for i,token in enumerate(items):
            if token == 'const':
                continue
            if token == '*':
                continue
            
            if brackets == 0:
                if token == '(':
                    brackets += 1
                else:
                    assert isword(token), token
                    head.append(token)
            elif brackets >= 1:
                if token == '(':
                    brackets += 1
                    arg += [token]
                elif token == ')':
                    brackets -= 1
                    if brackets == 0:
                        if arg:
                            args += [arg]
                        assert i == len(items)-1
                        break
                    else:
                        arg += [token]
                elif token == ',' and brackets == 1:
                    assert arg
                    args += [arg]
                    arg = []
                else:
                    arg += [token]
        
        assert len(head) >= 2, line
        retval,funcname = head[0:-1],head[-1]
        
        defargs = []
        
        pyfuncname = '_'.join(funcname.split('_')[2:])
        
        funcdef = funcname
        pyargs = ['self._ptr']
        defargs = ['self']
        for arg in args[1:]:
            if arg[-1] == ')':
                assert arg[1] == '(' and arg[3] == ')', arg
                argname = arg[2]
            else:
                argname = arg[-1]
            assert isword(argname)
            defargs.append(argname)
            if arg[0] == 'awe_string':
                argname = 'String.wrap({})'.format(argname) 
            pyargs.append(argname)
        funcdef = funcdef + '({})'.format(', '.join(pyargs))
        if retval != ['void']:
            if retval == ['awe_string']:
                funcdef = 'String.unwrap({})'.format(funcdef)
            funcdef = 'return ' + funcdef
        
        print('    def {}({}):'.format(pyfuncname, ', '.join(defargs)))
        print('        {}'.format(funcdef))
        print('') 
