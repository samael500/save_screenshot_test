from __future__ import (print_function, division, absolute_import)

import time
import os
import sys
import cffi

_ffi = cffi.FFI()

thisdir = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(thisdir, '..'))

from awesomium import *
from awesomium.internal import wrapstr

def test_awe():
    WebCore.initialize()
    
    val1 = JSValue.create(4)
    val2 = JSValue.create("hello")
    array = JSArray.create([val1,val2])
    assert array.get_size() == 2
    assert array.get_element(0).get_value() == 4
    assert array.get_element(1).get_value() == "hello"
    obj = JSObject.create()
    obj.set_property("a", 10)
    obj.set_property("b", "test")
    obj.set_property("c", val2)
    obj.set_property("d", array)
    assert obj.get_property("a").get_value() == 10
    assert obj.get_property("b").get_value() == "test"
    assert obj.get_property("c").get_value() == "hello"
    assert obj.get_keys().get_size() == 4
    
    loaded = {'a': 10, 'b': 'test', 'c': 'hello', 
        'd': [4, 'hello']}
    assert obj.to_native() == loaded
    
    d = [dict(a=4, b=3.4, c='test', d=None, e=True, f=loaded)]
    packed = JSValue.from_native(d) 
    assert packed.to_native() == d
    
    webview = WebCore.create_webview(640, 480)
    assert webview.get_url() == 'about:blank'
    rbuffer = webview.render()
    assert rbuffer.get_width() == 640
    assert rbuffer.get_height() == 480
    assert rbuffer.get_rowspan() == 640*4
    del webview
    WebCore.shutdown()

if __name__ == '__main__':
    test_awe()